# HiSpark WiFi IoT 开发套件编程速查



![](./HiSpark_WiFi_IoT_DevKits_Hardware_Quick_Reference.png)