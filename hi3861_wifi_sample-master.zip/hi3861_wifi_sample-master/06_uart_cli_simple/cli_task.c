#include "uart_cli_simple_api.h"

#define CLI_CMD_SUCCESS                0
#define CLI_CMD_ERROR                  1
#define CLI_LENGTH_ERROR               2
#define CLI_POINTER_NULL_ERROR         3

typedef struct
{
    const int cmd_id;              //指令ID
    const char* cmd;               //指令名
    const int cmd_length;          //需要比较的指令长度,最好是比较长度与指令长度一致  -->接收的字符串需要前几个字符吻合才能触发成功
    void  (*function)(char *param);//param可以根据需要做出改变，改成整型或者浮点型都可以，但是相应的解析需要自己手撸
}CLI_CMD;

//cli function
void hello_world_func(char* param);
void connect_mqtt_service_test(char* param);
void wifi_connect_init(char* param);
void wifi_task_disconnect(char* param);
void wifi_connect_try_again(char *param);
void mqtt_connect(char *param);
void wifi_connect(char *param);
void mqtt_send_data(char *param);

/**************注意： 指令比较长度一定不要超出指令本身长度！！！*******************/
/**************注意： 指令比较长度一定不要超出指令本身长度！！！*******************/
/**************注意： 指令比较长度一定不要超出指令本身长度！！！*******************/
static const CLI_CMD user_cli[] = 
{
    /*   1   5   9  1  1  1  */
    /*              2  5  8  */
    /************************测试用指令，直接发送cmd即可，无需任何参数***************************/
    {0, "hello_world",            10,   hello_world_func},              //example            --test PASS
    {1, "wifi_t_conn",            10,   wifi_connect_init},             //conn wifi          --test PASS
    {2, "wifi_disconn",           10,   wifi_task_disconnect},
    {3, "wifi_try_again",         10,   wifi_connect_try_again},
    {4, "mqtt_c_connect_test",    10,   connect_mqtt_service_test},     //mqtt test,         --test PASS
    /*************************正式指令************************************/
    {5, "mqtt_conn",              9,    mqtt_connect},                  //mqtt connect to    --test PASS
    {6, "wifi_conn",              9,    wifi_connect},                  //wifi connect to    --test PASS
    {7, "mqtt_send",              9,    mqtt_send_data}                 //send data to mqtt service   --test PASS
};

#define CLI_CMD_SIZE   sizeof(user_cli)/sizeof(user_cli[0])

typedef enum 
{
    CLI_PARSE_INIT,
}cli_cmd_parse_status;

#define CMD_CHAR_MAX_LENGTH    40
char cmd_char_buffer[CMD_CHAR_MAX_LENGTH] = {0x00,};
hi_u8 p_cmd = 0;


hi_u8 cli_cmd_handle(char* cli_cmd, char* cli_param)
{
    //if cmd is null, return
    /*如果命令是空的，则不执行*/
    if(cli_cmd == NULL)
        return CLI_CMD_ERROR;

    hi_u8 cli_cmd_poll_cnt = 0;
    for(cli_cmd_poll_cnt = 0; cli_cmd_poll_cnt < CLI_CMD_SIZE; cli_cmd_poll_cnt++)
    {
      if(!strncmp(cli_cmd, user_cli[cli_cmd_poll_cnt].cmd, user_cli[cli_cmd_poll_cnt].cmd_length))
      {
        /*命令与cli内相同，先判断是否有执行函数，再执行*/
        if(user_cli[cli_cmd_poll_cnt].function)
        {
          user_cli[cli_cmd_poll_cnt].function(cli_param);
        }
        cli_cmd_poll_cnt = CLI_CMD_SIZE; //跳出循环
      }
    }

    return CLI_CMD_SUCCESS;
}

/**
 * char buffer_data;
   for(hi_u16 a = 0; a < length; a++)
    {
        buffer_data = ch[a];
        hi_uart_write(HI_CLI_UART_PORT,  (hi_u8 *)&buffer_data, 1);
    }
*/

hi_u8 printf_buffer_char(char* ch, hi_u16 length)
{
    static hi_u8 buffer_data;
    if(length == 0)
        return CLI_LENGTH_ERROR;

    if(length > strlen(ch))
        return CLI_LENGTH_ERROR;

    if(ch == NULL)
        return CLI_POINTER_NULL_ERROR;

    for(hi_u16 a = 0; a < length; a++)
    {
        buffer_data = ch[a];
        hi_uart_write(HI_CLI_UART_PORT,  (hi_u8 *)&buffer_data, 1);
    }

    printf("\r\n");
    return CLI_CMD_ERROR;
}

void uart_cmd_parse(hi_u8 cmd)
{
    //从这里开始，将hi_u8字符数据转成char
    cmd_char_buffer[p_cmd] = cmd;
    p_cmd++;

    //'\n' ASCLL码是0x0A
    if(cmd == 0x0A)
    {
        cli_cmd_handle(cmd_char_buffer, cmd_char_buffer);
        printf_buffer_char(cmd_char_buffer, strlen(cmd_char_buffer));
        memset(cmd_char_buffer, 0x00, sizeof(cmd_char_buffer));
        p_cmd = 0;
    }  
}

///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

hi_void uart_cmd_task_scheduling(hi_u8 cmd)
{
    uart_cmd_parse(cmd);
}

void hello_world_func(char *param)
{
    if(param == NULL)
    {
        //do nothing
    }

    cli_printf("hello!\r\n");
}

void connect_mqtt_service_test(char *param)
{
    if(param == NULL)
    {
        //do nothing
    }
    mqtt_connect_test();
}

void wifi_connect_init(char *param)
{
    if(param == NULL)
    {
        //do nothing
    }
    //cli_printf("wifi_connect_task_creat is trigger!");
    wifi_connect_task_creat();
}

void wifi_task_disconnect(char *param)
{
    if(param == NULL)
    {
        //do nothing
    }
    wifi_disconnect();
}

void wifi_connect_try_again(char *param)
{
    if(param == NULL)
    {
        //do nothing
    }

    wifi_connect_again();
}

void mqtt_connect(char *param)
{
    if(param == NULL)
    {
        cli_printf("please input mqtt ip and port!");
    }

    char cmd_buff[CMD_CHAR_MAX_LENGTH] = {0x00,};
    strcpy(cmd_buff, param);

    char buffer_data;
    hi_u8 maohao_cnt = 0; //英语引号的个数
    hi_u8 ip_param_start = 0;
    hi_u8 ip_param_stop = 0;
    hi_u8 port_param_start = 0;
    hi_u8 port_param_stop = 0;
    for(hi_u16 a = 0; a < CMD_CHAR_MAX_LENGTH; a++)
    {
        buffer_data = cmd_buff[a];

        if(buffer_data == 0x22)
        {
            maohao_cnt++;
            if(maohao_cnt == 1)
            {
                ip_param_start = a+1;
                //cli_printf("ip_param_start is %d", ip_param_start);
            }

            if(maohao_cnt == 2)
            {
                ip_param_stop = a-1;
                //cli_printf("ip_param_stop is %d", ip_param_stop);
            }
            
            if(maohao_cnt == 3)
            {
                port_param_start = a+1;
                //cli_printf("port_param_start is %d", port_param_start);
            }

            if(maohao_cnt == 4)
            {
                port_param_stop = a-1;
                //cli_printf("port_param_stop is %d", port_param_stop);
                a = CMD_CHAR_MAX_LENGTH;
            }
        }
    }

    char mqtt_ip_addr[16] = {0x00,};
    char mqtt_port[5] = {0x00,};
    
    hi_u16 len_cut = 0;
    len_cut = str_cut_out(mqtt_ip_addr, cmd_buff, ip_param_start, ip_param_stop);
    CHECK_PARAM_INT("len_cut", len_cut);
    len_cut = str_cut_out(mqtt_port, cmd_buff, port_param_start, port_param_stop);
    CHECK_PARAM_INT("len_cut", len_cut);

    // printf_buffer_char(cmd_buff, strlen(cmd_buff));
    // printf_buffer_char(mqtt_ip_addr, strlen(mqtt_ip_addr));
    // printf_buffer_char(mqtt_port, strlen(mqtt_port));

    mqtt_client_connect_to_serv(mqtt_ip_addr, mqtt_port);
}


void wifi_connect(char *param)
{
    if(param == NULL)
    {
        cli_printf("please input wifi ssid and passkey!");
    }

    char wifi_cmd_buff[CMD_CHAR_MAX_LENGTH] = {0x00,};
    strcpy(wifi_cmd_buff, param);

    char wifi_ssid[20] = {0x00,};
    char wifi_key[10] = {0x00,};
    get_cmd_2_param(wifi_cmd_buff, wifi_ssid, wifi_key);
    wifi_conn_to_AP(wifi_ssid, wifi_key);
}

void mqtt_send_data(char *param)
{
    if(param == NULL)
    {
        cli_printf("please input mqtt send data!");
    }
    char mqtt_data[20] = {0x00,};
    get_cmd_1_param(param, mqtt_data);
    cli_printf("will send data to mqtt!");

    mqtt_send_to_service(mqtt_data);
}