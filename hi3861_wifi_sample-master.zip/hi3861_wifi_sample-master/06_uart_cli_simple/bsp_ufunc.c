#include "uart_cli_simple_api.h"

hi_u16 str_cut_out(char* buff, char* array_slice, hi_u8 start_addr, hi_u8 stop_addr)
{
    hi_u16 cnt = 0;
    for(hi_u8 cut_addr = start_addr; cut_addr <= stop_addr; cut_addr++)
    {
        buff[cnt] = array_slice[cut_addr];
        cnt++;
    }

    return cnt;
}

// void str_to_int(char* ch_param)
// {
 
// }
hi_void get_cmd_2_param(char* cmd_buff, char* first_param, char* second_param)
{
    char buff_data;
    hi_u16 data_length = strlen(cmd_buff);
    hi_u8 first_strat = 0, first_stop = 0;
    hi_u8 second_start = 0, second_stop = 0;
    hi_u8 maohao_cnt = 0; //英语引号的个数

    for(hi_u16 a = 0; a < data_length; a++)
    {
        buff_data = cmd_buff[a];

        if(buff_data == 0x22)  //0x22就是 " 的ASCLL码
        {
            maohao_cnt++;
            if(maohao_cnt == 1)
            {
                first_strat = a+1;
                debug_printf("first_strat is %d", first_strat);
            }

            if(maohao_cnt == 2)
            {
                first_stop = a-1;
                debug_printf("first_stop is %d", first_stop);
            }
            
            if(maohao_cnt == 3)
            {
                second_start = a+1;
                debug_printf("second_start is %d", second_start);
            }

            if(maohao_cnt == 4)
            {
                second_stop = a-1;
                debug_printf("second_stop is %d", second_stop);
                a = data_length;
            }
        }
    }

    hi_u16 len_cut = 0;
    len_cut = str_cut_out(first_param, cmd_buff, first_strat, first_stop);
    CHECK_PARAM_INT("len_cut", len_cut);
    len_cut = str_cut_out(second_param, cmd_buff, second_start, second_stop);
    CHECK_PARAM_INT("len_cut", len_cut);
}

hi_void get_cmd_1_param(char* cmd_buff, char* first_param)
{
    char buff_data;
    hi_u16 data_length = strlen(cmd_buff);
    hi_u8 first_strat = 0, first_stop = 0;
    hi_u8 maohao_cnt = 0; //英语引号的个数

    for(hi_u16 a = 0; a < data_length; a++)
    {
        buff_data = cmd_buff[a];

        if(buff_data == 0x22)  //0x22就是 " 的ASCLL码
        {
            maohao_cnt++;
            if(maohao_cnt == 1)
            {
                first_strat = a+1;
                debug_printf("first_strat is %d", first_strat);
            }

            if(maohao_cnt == 2)
            {
                first_stop = a-1;
                debug_printf("first_stop is %d", first_stop);
            }
        }
    }

    hi_u16 len_cut = 0;
    len_cut = str_cut_out(first_param, cmd_buff, first_strat, first_stop);
    CHECK_PARAM_INT("len_cut", len_cut);
}