#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ohos_init.h"
#include "ohos_types.h"

#include "hi_types_base.h"          //各个hi_xx 变量名来源
#include "hi_uart.h"                //串口驱动
#include "hi3861_platform_base.h"   //硬件IO/UART等名称
#include "hi_event.h"
#include "hi_task.h"
#include "hi_lowpower.h"
#include "hi_timer.h"

/*********************************************************************/
/***************************cli uart define***************************/
/*********************************************************************/
#define USE_USB_UART                    1    /*将uart0初始化位输出口，需要先将AT指令屏蔽，具体见readme.md文件  --已测试，可用*/
#define MQTT_CLIENT_ENABLE              1    /*使能MQTT*/  
#define UART_WAKE_UP_SAVE_CONFIG        0    /*进入深睡眠前保存uart配置信息，但是将IO屏蔽了，有需要可以自行开启 --未测试*/
#define DEBUG_ENABLE                    1    /*调试log开关*/

#if defined(USE_USB_UART) && (USE_USB_UART == 1)
#define HI_CLI_UART_PORT             HI_UART_IDX_0
#else
#define HI_CLI_UART_PORT             HI_UART_IDX_1
#endif



//用于调试
#define APP_ERR_CHECK(x)     if (x != HI_ERR_SUCCESS) {printf("[%s : %d]there are some error open.errcode:%d\r\n",__func__, __LINE__, x);return x;}
#define cli_printf(_fmt_, ...) printf("[%s : %d]" _fmt_ "\r\n", __func__, __LINE__, ##__VA_ARGS__)
#if defined(DEBUG_ENABLE) && (DEBUG_ENABLE == 1)
#define debug_printf(_fmt_, ...) printf("[%s : %d]" _fmt_ "\r\n", __func__, __LINE__, ##__VA_ARGS__)
#else
#define debug_printf(_fmt_, ...) NULL
#endif

#define CHECK_PARAM_INT(__str__, __value__)  cli_printf("check out the %s:%d",__str__,__value__)
#define CHECK_PARAM(__value__)  cli_printf("check out the %d",__value__)
/**
 * @brief 解析uart_cli_simple例程中串口接收到的cmd，解析并调用相关执行函数。
 * @note 不支持多条指令并发，也不要直接多线程调用，串口接收的同时直接
 * @param hi_u8 cmd:单个字符，而不是字符串起始地址
*/
hi_void uart_cmd_task_scheduling(hi_u8 cmd);

/**
 * @brief 输出buffer数组内的字符串
 * @param char* h：buffer数组内，字符串的起始地址
 * @param hi_u16 length 需要打印的字符串长度，注意不要超出buffer本身的长度
 * @retval CLI_LENGTH_ERROR : 超出字符串长度或者为0
 * @retval CLI_POINTER_NULL_ERROR : 指针为空
*/
hi_u8 printf_buffer_char(char* ch, hi_u16 length);

/**
 * @brief 创建WiFi连接任务：包括WiFi初始化，WiFi连接
*/
void wifi_connect_task_creat(void);

/**
 * @brief 断开WiFi连接
*/
void wifi_disconnect(void);

/**
 * @brief 尝试WiFi重新连接
*/
void wifi_connect_again(void);

/**
 * @brief 连接到wifi
*/
void wifi_conn_to_AP(char* wifi_ssid, char* wifi_passkey);

/**************************************************************************************/
/*************************************bsp_ufunc.c**************************************/
/**************************************************************************************/

/**
 * @brief 用于任意裁剪字符串，从array_slice[start_addr] 到 array_slice[stop_addr]，裁剪给buff
 * @param buff : 用于放置裁剪后的数据
 * @param array_slice : 需要裁剪的数据
 * @param start_addr : 从start_addr开始裁剪
 * @param stop_addr : 裁剪到stop_addr结束
*/
hi_u16 str_cut_out(char* buff, char* array_slice, hi_u8 start_addr, hi_u8 stop_addr);

/**
 * @brief 用于摘取字符中的指令参数，参数只摘取指令中""内的参数
 * @param cmd_buff 指令数据
 * @param first_param 第一个""中的数据
 * @param second_param 第二个""中的数据
*/
hi_void get_cmd_2_param(char* cmd_buff, char* first_param, char* second_param);

hi_void get_cmd_1_param(char* cmd_buff, char* first_param);
/**************************************************************************************/
/*************************************mqtt_connect.c***********************************/
/**************************************************************************************/

/**
 * @brief 用于测试mqtt的函数，
 * 需要在函数内提前修改好ip地址
 * @see 李老师友情提供 https://harmonyos.51cto.com/posts/1384
*/
int mqtt_connect_test(void);
/**
 * @brief 用于连接mqtt服务器，使用这个之前需要先连接可用wifi 
 * @see wifi_connect_task_creat
 * @param mqtt_ip   mqtt服务器ip，注意不是wifi/热点的ip
 * @param mqtt_port mqtt服务器端口号，最大不能超过65535
*/
void mqtt_client_connect_to_serv(char* mqtt_ip, char* mqtt_port);


void mqtt_send_to_service(char* param);

