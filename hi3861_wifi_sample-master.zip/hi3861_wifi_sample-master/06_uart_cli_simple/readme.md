在使用本例子前，需要清楚如下几点：

## 声明与介绍
1.本例子使用的是hi3861开发板，并且使用开源社区内的最新源代码（202102）

2.本例子使用的串口UART0,也就是转USB(tpye-c)的那个，与AT指令的串口冲突，因此解决这个由两个方案
方案一：懒逼快速方案：
    忽略AT会报错的`ERROR` log,或者将AT模块的hi_at.c下(`vendor\hisi\hi3861\hi3861\components\at\src`)的串口接收屏蔽
        `n = hi_uart_read(g_at_uart_port, (hi_u8 *)&ch, 1);`
        `n = g_at_input_func((UINT8 *)&ch, 1);`

方案二：接线手法娴熟的：直接接个其它串口，将例程中
`#define HI_CLI_UART_PORT             HI_UART_IDX_0`
改成你所需要的

3.功能可在`uart_cli_simple_api.h`中通过宏定义进行删减，尽量做到可以任意剔除添加模块，但是有些强相关的就不行了:)

4.mqtt 移植方案可查看连老师的https://harmonyos.51cto.com/posts/1384
我也是学习连老师的

5.mqtt源码来源于https://github.com/eclipse/paho.mqtt.embedded-c


## 注意事项
1.似乎在`\\vendor\lwip\`下有mqtt client,但是我还没试过  --待测试

2.我将mqtt放在了`\\HarmonyOS-IoT-Application-Development\06_uart_cli_simple\third_party`只是为了方便放到仓库，当然，放在`openHarmonythird_party\third_party`下才是符合SDK一般规则，但是我并不像将整个openharmony 源码push到仓库，我这里的想法是：
只需要pull我的源码，编译完之后就可以直接使用，不需要多余操作


## mqtt 连接
### 账号和密码设置
记得服务器需要生成鉴权账号

`data.username.cstring = "testuser";`
`data.password.cstring = "testpassword";`

例如我创建了一个：
账号：protea111
密码：12345678

然后相对应的账号和密码进行修改
`data.username.cstring = "protea111";`
`data.password.cstring = "12345678";`

这里更好的是产线烧写到flash，然后产品上电后读取唯一的用户名和密码
服务器再批量导入出厂的用户名和密码，进行鉴权

### mqtt服务器IP设置
`char *host = "192.168.1.1"; //小邹的mqtt ip `
这个不是wifi地址，而是创建的mqtt服务器ip

### window客户端设置
见相关md或者链接：https://harmonyos.51cto.com/posts/1384

### mqtt客户端主题名设置
`topicString.cstring = "pubtopic";`

如果要分层，可以直接这样设置： `pubtopic/app`

### mqtt客户端订阅设置
`topicString.cstring = "substopic";`  --以实际主题为准

## 如何编译
可以将本仓整体拷贝到openharmony源码树下，和`applications`同级；

1. 修改openharmony源码的`build\lite\product\wifiiot.json`文件，将其中的:

      `//applications/sample/wifi-iot/app`替换为：`//HarmonyOS-IoT-Application-Development:app`

2. 将AT模块的hi_at.c下(`vendor\hisi\hi3861\hi3861\components\at\src`)的串口接收屏蔽
        `n = hi_uart_read(g_at_uart_port, (hi_u8 *)&ch, 1);`
        `n = g_at_input_func((UINT8 *)&ch, 1);`

3. 在openharmony源码顶层目录执行：`python build.py wifiiot`

最后如果出现如下log则是编译成功
`< ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ >`
`                              BUILD SUCCESS                              `
`< ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ >`

## 如何操作？
### 1.先将代码烧录到开发版上
如果完全新手，先将doc下的`环境搭建.md`,`获取harmony源码.md` `开始第一个代码.md` `开始第二个代码.md`学习并操作成功后，再来这一步

### 2.打开sscom或者其它串口工具，连接开发版com口
波特率 `115200`
使能 `加回车换行`
复位设备，看见如下log则是复位成功

ready to OS start
sdk ver:Hi3861V100R001C00SPC025 2020-09-03 18:10:00
FileSystem mount ok.
uart0 is init!
AT init complete!
wifi init success!
uart0 is init!
uart cli init test!\0[cli_uart_task_body : 120]cli_uart_task_body task run normal!

[cli_proc_task_body : 110]cli_proc_task_body task run normal!
00 00:00:00 0 196 D 0/HIVIEW: hilog init success.
00 00:00:00 0 196 D 0/HIVIEW: log limit init success.
00 00:00:00 0 196 I 1/SAMGR: Bootstrap core services(count:3).
00 00:00:00 0 196 I 1/SAMGR: Init service:0x4b12bc TaskPool:0xf2cb8
00 00:00:00 0 196 I 1/SAMGR: Init service:0x4b12e0 TaskPool:0xf2cd8
00 00:00:00 0 196 I 1/SAMGR: Init service:0x4b13f0 TaskPool:0xf2e98
00 00:00:00 0 172 I 1/SAMGR: Init service 0x4b12e0 <time: 10ms> success!
00 00:00:00 0 72 I 1/SAMGR: Init service 0x4b12bc <time: 20ms> success!
00 00:00:00 0 16 D 0/HIVIEW: hiview init success.
00 00:00:00 0 16 I 1/SAMGR: Init service 0x4b13f0 <time: 20ms> success!
00 00:00:00 0 16 I 1/SAMGR: Initialized all core system services!
00 00:00:00 0 72 I 1/SAMGR: Bootstrap system and application services(count:0).
00 00:00:00 0 72 I 1/SAMGR: Initialized all system and application services!
00 00:00:00 0 72 I 1/SAMGR: Bootstrap dynamic registered services(count:0).

### 3.发送指令连接wifi
1. 见doc下的 `wifi指令.md`

### 4.下载并解压mqtt客户端，订阅相关主题
操作步奏见https://harmonyos.51cto.com/posts/1384 后半部分，
mqtt相关配置要设置对，订阅的主题与相关代码中一致 `topicString.cstring = "pubtopic_112233";`
即应该订阅`pubtopic_112233`

### 5.串口发送指令连接mqtt服务器，并发送数据
1. 指令见doc下 `mqtt指令.md`

### 6.见到window客户端有收到订阅数据，则操作成功

### 7.window客户端发布数据给设备
发布主题应该与相关代码一致 `topicString.cstring = "substopic";`
即发布主题应改为`substopic`
然后看见串口打印`message arrived + 接收到的数据`
例如 `message arrived hello,device`即设备接收成功

## 遇到的问题
### 串口没有数据
1.sscom发送带有回车换行的数据时，串口`hi_uart_read`接收不到数据，导致透传失败  
--只出现过一次，就很神奇 
--我怀疑是我没烧写成功，代码还是有AT模块，而AT模块不加回车换行会将指令直接返回，加了回车换行会直接解析

### wifi连接失败
使用04_wifi例程，将相关代码移植到当前项目，然后测试连接wifi/热点，连接失败，系统死锁
1.经过排查，是由于`ConnectTo()`调用了相关AT指令进行WiFi连接，而我原先屏蔽了AT模块，所以导致死锁。
2.开启AT模块，本项目也能收到数据并解析...
关于串口接收，需要研究一下是什么原理。
3.为了防止AT模块串口接收抢占

### hisi 3861 太久没上传数据，mqtt连接断开
暂无好想法，建议定时几秒钟一直上抛数据