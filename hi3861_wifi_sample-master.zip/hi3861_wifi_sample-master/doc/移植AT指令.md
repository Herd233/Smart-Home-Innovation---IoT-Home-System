# 移植AT指令

## 移植wifi相关功能

```
const at_cmd_func g_sta_func_tbl[] = {
    {"+STOPSTA", 8, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_sta_stop},
    {"+SCAN", 5, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_wpa_scan},
    {"+SCANCHN", 8, HI_NULL, HI_NULL, (at_call_back_func)cmd_wpa_channel_scan, HI_NULL},
    {"+SCANSSID", 9, HI_NULL, HI_NULL, (at_call_back_func)cmd_wpa_ssid_scan, HI_NULL},
    {"+SCANPRSSID", 11, HI_NULL, HI_NULL, (at_call_back_func)cmd_ssid_prefix_scan, HI_NULL},
    {"+SCANRESULT", 11, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_wpa_scan_results},
    {"+CONN", 5, HI_NULL, HI_NULL, (at_call_back_func)cmd_sta_connect, HI_NULL},
    {"+FCONN", 6, HI_NULL, HI_NULL, (at_call_back_func)cmd_sta_quick_connect, HI_NULL},
    {"+DISCONN", 8, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_sta_disconnect},
    {"+STASTAT", 8, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_sta_status},
    {"+RECONN", 7, HI_NULL, HI_NULL, (at_call_back_func)cmd_set_reconn, HI_NULL},
#ifdef CONFIG_WPS_SUPPORT
    {"+PBC", 4, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_wpa_wps_pbc},
    {"+PIN", 4, HI_NULL, HI_NULL, (at_call_back_func)cmd_wpa_wps_pin, HI_NULL},
    {"+PINSHOW", 8, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_wpa_wps_pin_get},
#endif /* LOSCFG_APP_WPS */
#ifdef CONFIG_TEE_HUKS_DEMO_SUPPORT
    {"+GCONNKEY", 9, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_generate_save_conn_key},
    {"+SCONN", 6, HI_NULL, HI_NULL, (at_call_back_func)cmd_sta_secure_connect, HI_NULL},
    {"+SRCONN", 7, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_sta_secure_re_connect},
#endif
};
```

```
const at_cmd_func g_sta_factory_test_func_tbl[] = {
    {"+STARTSTA", 9, HI_NULL, HI_NULL, (at_call_back_func)cmd_sta_start_adv, (at_call_back_func)cmd_sta_start},
#ifdef CONFIG_TEE_HUKS_DEMO_SUPPORT
    {"+GCERTKEY", 9, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_generate_save_cert_key},
    {"+CERTENC", 8, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_encrypt_cert},
    {"+CERTDEC", 8, HI_NULL, HI_NULL, HI_NULL, (at_call_back_func)cmd_decrypt_cert},
#endif
};
```


### 开始STA模式
```
/*****************************************************************************
* Func description: start sta
*****************************************************************************/
hi_u32 cmd_sta_start(hi_s32 argc, const hi_char *argv[])
{
    hi_unref_param(argv);
    hi_unref_param(argc);
#ifndef CONFIG_FACTORY_TEST_MODE
    hi_s32  ret;
    hi_char ifname[WIFI_IFNAME_MAX_SIZE + 1] = {0};
    hi_s32  len = sizeof(ifname);

    ret = hi_wifi_sta_start(ifname, &len);
    if (ret != HISI_OK) {
        return HI_ERR_FAILURE;
    }
#else
    if (wal_add_cfg_vap() != HI_ERR_SUCCESS) {
        return HI_ERR_FAILURE;
    }
#endif
    hi_at_printf("OK\r\n");
    return HI_ERR_SUCCESS;
}
```
```
hi_u32 cmd_sta_start_adv(hi_s32 argc, const hi_char *argv[])
{
    hi_s32  ret;
    hi_wifi_bw bw = HI_WIFI_BW_LEGACY_20M;

    if (argc != 3) { /* "+STARTSTA" command fix 3 parameters */
        return HI_ERR_FAILURE;
    }

    ret = (hi_s32)sta_start_adv_param(argc, argv, &bw);
    if (ret != HI_ERR_SUCCESS) {
        return HI_ERR_FAILURE;
    }
#ifndef CONFIG_FACTORY_TEST_MODE
    hi_char ifname[WIFI_IFNAME_MAX_SIZE + 1] = {0};
    hi_s32  len = sizeof(ifname);
    ret = hi_wifi_sta_start(ifname, &len);
    if (ret != HISI_OK) {
        return HI_ERR_FAILURE;
    }
#endif
    ret = hi_wifi_set_bandwidth(DEFAULT_IFNAME_STA, strlen(DEFAULT_IFNAME_STA) + 1, bw);
    if (ret != HI_ERR_SUCCESS) {
#ifndef CONFIG_FACTORY_TEST_MODE
        hi_wifi_sta_stop();
#endif
        return HI_ERR_FAILURE;
    }

    hi_at_printf("OK\r\n");
    return HI_ERR_SUCCESS;
}
```

