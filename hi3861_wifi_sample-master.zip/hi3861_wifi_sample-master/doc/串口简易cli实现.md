# 串口简易cli实现
## 首先屏蔽AT指令
查看硬件IO，因为目前就一个物理串口`HI_UART_IDX_0`是uart转USB，可以直接从type-C接口获取串口数据
但是如果是有其它需求，选择其它串口也不要紧，跳过此步
```
    defines = [
        "LOS_COMPILE_LDM",
        "PRODUCT_USR_SOFT_VER_STR=\"None\"",
        "CYGPKG_POSIX_SIGNALS",
        "__ECOS__",
        "__RTOS_",
        "PRODUCT_CFG_HAVE_FEATURE_SYS_ERR_INFO",
        "__LITEOS__",
        "LIB_CONFIGURABLE",
        "LOSCFG_SHELL",
        "LOSCFG_CACHE_STATICS",
        "CUSTOM_AT_COMMAND",
        "LOS_COMPILE_LDM",
        "LOS_CONFIG_IPERF3",
        "CMSIS_OS_VER=2",
        "SECUREC_ENABLE_SCANF_FILE=0",
        #"CONFIG_AT_COMMAND",// disable AT cmd
        "PRODUCT_CFG_CHIP_VER_STR=\"Hi3861V100\"",
        "CHIP_VER_Hi3861",
        "PRODUCT_CFG_SOFT_VER_STR=\"Hi3861\"",
        "HI_BOARD_ASIC",
        "HI_ON_FLASH",
        "LITEOS_WIFI_IOT_VERSION",
    ]
```

编译烧写后，测试一下，发现AT指令的确无了
## 宏定义与参数
```
#define HI_CLI_UART_PORT        HI_UART_IDX_1

#define CLI_DEFAULT_UART_TASK_SIZE   0x600
#define CLI_UART_TASK_PRIO           9
#define CLI_DEFAULT_PROC_TASK_SIZE   0xC00 /* 0x800:softap start would fail. */
#define CLI_PROC_TASK_PRIO           10
#define CLI_UART_SLEEP               1000
#define APP_ERR_CHECK(x)     if (x != HI_ERR_SUCCESS) {printf("[%s : %d]there are some error open.errcode:%d\r\n",__func__, __LINE__, x);return x;}

#define cli_printf(_fmt_, ...) printf("[%s : %d]" _fmt_ "\r\n", __func__, __LINE__, ##__VA_ARGS__)
/***************************/
/******cli uart params******/
/***************************/
const hi_uart_attribute g_cli_uart_cfg  = {115200, 8, 1, 0, 0};
uintptr_t g_cli_uart_baseaddr = HI_UART1_REG_BASE;
hi_bool g_cli_init = HI_FALSE;
hi_u32 g_cli_event = 0;
hi_u16 g_cli_proc_task_size = CLI_DEFAULT_PROC_TASK_SIZE;
hi_u16 g_cli_uart_task_size = CLI_DEFAULT_UART_TASK_SIZE;

```
## 新建应用进行串口初始化
项目建立在vendor下或者建立在wifiiot目录下都可以，只要有编译就行

然后我在之前hello world项目的同级路径下，新建了一个uart_cli_app
![](_v_images/20210220091906631_11098.png =166x)

代码如下
```
/**
 * @brief 初始化cli串口，用于接收串口指令
 * 参考格式来源：at_uart_init()
*/
hi_u32 cli_uart_init(hi_void)
{
    hi_u32 ret;

    (hi_void)hi_uart_deinit(HI_CLI_UART_PORT);
    ret = hi_uart_init(HI_CLI_UART_PORT, &g_cli_uart_cfg, HI_NULL);
    if (ret != HI_ERR_SUCCESS) {
        return HI_ERR_FAILURE;
    }

    if (HI_CLI_UART_PORT == HI_UART_IDX_0) {
        g_cli_uart_baseaddr = HI_UART0_REG_BASE;
    } else if (HI_CLI_UART_PORT == HI_UART_IDX_1) {
        g_cli_uart_baseaddr = HI_UART1_REG_BASE;
    } else if (HI_CLI_UART_PORT == HI_UART_IDX_2) {
        g_cli_uart_baseaddr = HI_UART2_REG_BASE;
    }

    return HI_ERR_SUCCESS;
}
```


## 创建任务并运行串口透传
### 串口透传任务
```
hi_void *cli_uart_task_body(hi_void* param)
{
    hi_unref_param(param);
    cli_printf("cli_uart_task_body task run normal!");
    hi_char ch;
    hi_s32 n;

    for (;;) 
    {
        n = hi_uart_read(HI_CLI_UART_PORT, (hi_u8 *)&ch, 1);
        if (n != 1) {
            (hi_void)hi_sleep(CLI_UART_SLEEP);
            continue;
        }
        else
        {
          //for test
          printf("%c", ch);
        }
    }
}
```

### 创建任务并执行
```
/**
 * @brief 用于创建simple cli uart任务，
 * 接收指令、解析指令并调用相关函数执行
*/
hi_u32 cli_uart_init_task(hi_void)
{
    hi_u32 ret;
    hi_u32 cli_uart_task, cli_proc_task;
    cli_printf("!!start init cli uart!!");
    //初始化串口，默认为UART1
    ret = cli_uart_init();
    if (ret != HI_ERR_SUCCESS) {
        cli_printf("An error occurred at cli_uart_init!");
        return ret;
    }
    //创建cli事件，获取cli事件使用ID
    hi_event_create(&g_cli_event);
    hi_task_attr attr = {0};

    //创建cli 功能函数任务
    attr.stack_size = g_cli_proc_task_size;
    attr.task_prio = CLI_PROC_TASK_PRIO;    
    attr.task_name = (void*)"cli_proc";
    ret = hi_task_create(&cli_proc_task, &attr, cli_proc_task_body, 0);
    APP_ERR_CHECK(ret);

    //创建串口收发与指令解析任务
    attr.stack_size = g_cli_uart_task_size;
    attr.task_prio = CLI_UART_TASK_PRIO;    
    attr.task_name = (void*)"cli_uart";
    ret = hi_task_create(&cli_uart_task, &attr, cli_uart_task_body, 0);
    APP_ERR_CHECK(ret);

    return ret;
}

//用于运行SYS_RUN
void cli_uart_main(void)
{
    cli_uart_init_task();
}

SYS_RUN(cli_uart_main);
```


### 调试透传结果
> [10:28:04.198]收←◆ready to OS start
> sdk ver:Hi3861V100R001C00SPC025 2020-09-03 18:10:00
> formatting spiffs...
> 
> [10:28:04.531]收←◆FileSystem mount ok.
> wifi init success!
> [cli_uart_init_task : 99]!!start init cli uart!!
> [cli_uart_task_body : 72]cli_uart_task_body task run normal!
> 
> [cli_proc_task_body : 62]cli_proc_task_body task run normal!
> 00 00:00:00 0 132 D 0/HIVIEW: hilog init success.
> 00 00:00:00 0 132 D 0/HIVIEW: log limit init success.
> 00 00:00:00 0 132 I 1/SAMGR: Bootstrap core services(count:3).
> 00 00:00:00 0 132 I 1/SAMGR: Init service:0x4ae6fc TaskPool:0xf2578
> 00 00:00:00 0 132 I 1/SAMGR: Init service:0x4ae720 TaskPool:0xf2598
> 00 00:00:00 0 132 I 1/SAMGR: Init service:0x4ae830 TaskPool:0xf2758
> 00 00:00:00 0 108 I 1/SAMGR: Init service 0x4ae720 <time: 10ms> success!
> 00 00:00:00 0 8 I 1/SAMGR: Init service 0x4ae6fc <time: 20ms> success!
> 00 00:00:00 0 208 D 0/HIVIEW: hiview init success.
> 00 00:00:00 0 208 I 1/SAMGR: Init service 0x4ae830 <time: 20ms> success!
> 00 00:00:00 0 208 I 1/SAMGR: Initialized all core system services!
> 00 00:00:00 0 8 I 1/SAMGR: Bootstrap system and application services(count:0).
> 00 00:00:00 0 8 I 1/SAMGR: Initialized all system and application services!
> 00 00:00:00 0 8 I 1/SAMGR: Bootstrap dynamic registered services(count:0).
> 
> [10:28:25.642]发→◇forceMode 200
> □
> [10:28:25.647]收←◆forceMode 200
> ERROR
> 
> [10:28:30.842]发→◇forceMode 200□
> [10:28:30.846]收←◆forceMode 200
> [10:28:32.059]发→◇forceMode 200□
> [10:28:32.063]收←◆forceMode 200
> [10:28:32.891]发→◇forceMode 200□
> [10:28:32.895]收←◆forceMode 200
> [10:28:33.345]发→◇forceMode 200□
> [10:28:33.349]收←◆forceMode 200
> [10:28:33.602]发→◇forceMode 200□
> [10:28:33.606]收←◆forceMode 200
> [10:28:33.794]发→◇forceMode 200□
> [10:28:33.798]收←◆forceMode 200

这里有个问题，就是在发送的数据带上回车换行之后，会多出一个`ERROR`log，

经过分析，这个应该是在AT指令解析的时候报的错误，然后发现AT指令打印log都是通过`hi_at_printf`
那么我们改变一下打印方式即可，多加log所在函数名和行数
> note：注意#define要放在.h文件中
> 并且将`hi_s32 hi_at_printf_crashinfo(const hi_char *fmt, ...);`注释掉

```
#define hi_at_printf(_fmt_, ...) printf("[%s : %d]" _fmt_, __func__, __LINE__, ##__VA_ARGS__)

#if 0
hi_s32 hi_at_printf(const hi_char *fmt, ...)
{
    va_list ap = 0;
    hi_s32 len;
    va_start(ap, fmt);

#if defined(CONFIG_AT_COMMAND) || defined(CONFIG_FACTORY_TEST_MODE)
    OUTPUT_FUNC fn_put = (OUTPUT_FUNC)uart_puts_at;
    len = __dprintf(fmt, ap, fn_put, (void *)NULL);
#else
    len = 0;
#endif

    va_end(ap);
    return len;
}
#endif
```
然而这样会导致libwifi_flash.a编译的时候报错，所以直接换个笨办法
![](_v_images/20210221133632912_30818.png =196x)

### 找出ERROR log
定义一个debug用的输出函数
```
#define hi_at_printf_debug(_fmt_, ...) printf("[%s : %d]" _fmt_, __func__, __LINE__, ##__VA_ARGS__)
```
然后将所有使用`hi_at_printf`打印`ERROR`全部替换成hi_at_printf_debug
最后编译烧写，得到如下
> [13:47:20.648]发→◇forceMode 200
> 
> [13:47:20.652]收←◆forceMode 200
> [at_cmd_execute : 479]ERROR

很明显，通过查看代码发现，at_proc_task_body还是有执行的

