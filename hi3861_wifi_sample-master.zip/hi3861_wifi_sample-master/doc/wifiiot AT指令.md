# wifiiot AT指令
在DevEco的串口终端中，依次执行如下AT命令，启动STA模式，连接指定AP热点，并开启DHCP功能
```
AT+STARTSTA                             - 启动STA模式
AT+SCAN                                 - 扫描周边AP
AT+SCANRESULT                           - 显示扫描结果
AT+CONN="SSID",,2,"PASSWORD"            - 连接指定AP，其中SSID/PASSWORD为待连接的热点名称和密码
AT+STASTAT                              - 查看连接结果
AT+DHCP=wlan0,1                         - 通过DHCP向AP请求wlan0的IP地址
```
```
AT+IFCFG                                - 查看模组接口IP
AT+PING=X.X.X.X                         - 检查模组与网关的联通性，其中X.X.X.X需替换为实际的网关地址
```

```
AT+HELP
+HELP:
AT                 AT+RST             AT+MAC             AT+HELP
AT+SYSINFO         AT+DHCP            AT+DHCPS           AT+NETSTAT
AT+PING            AT+PING6           AT+DNS             AT+DUMP
AT+IPSTART         AT+IPLISTEN        AT+IPSEND          AT+IPCLOSE
AT+XTALCOM         AT+RDTEMP          AT+STOPSTA         AT+SCAN
AT+SCANCHN         AT+SCANSSID        AT+SCANPRSSID      AT+SCANRESULT      
AT+CONN            AT+FCONN           AT+DISCONN         AT+STASTAT
AT+RECONN          AT+STARTAP         AT+SETAPADV        AT+STOPAP
AT+SHOWSTA         AT+DEAUTHSTA       AT+APSCAN          AT+RXINFO
AT+CC              AT+TPC             AT+TRC             AT+SETRATE
AT+ARLOG           AT+VAPINFO         AT+USRINFO         AT+SLP
AT+WKGPIO          AT+USLP            AT+ARP             AT+PS
AT+ND              AT+CSV             AT+FTM             AT+FTMERASE        
AT+SETUART         AT+IFCFG           AT+STARTSTA        AT+ALTX
AT+ALRX            AT+CALFREQ         AT+SETRPWR         AT+RCALDATA        
AT+SETIOMODE       AT+GETIOMODE       AT+GPIODIR         AT+WTGPIO
AT+RDGPIO
```

