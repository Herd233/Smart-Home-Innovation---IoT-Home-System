# 环境搭建成功的log
> 
> === start build ===
> 
> Done. Made 57 targets from 53 files in 1225ms
> ninja: Entering directory `/home/openharmony/HarmonyCode/out/wifiiot'
> [1/197] STAMP obj/applications/sample/wifi-iot/app/startup/startup.stamp
> [2/197] STAMP obj/applications/sample/wifi-iot/app/app.stamp
> [3/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/reset.o
> [4/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_adc.o
> [5/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_flash.o
> [6/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/lowpower.o
> [7/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_kal.o
> [8/197] cross compiler obj/base/hiviewdfx/utils/lite/hiview_config.o
> [9/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_gpio.o
> [10/197] cross compiler obj/base/hiviewdfx/frameworks/hilog_lite/mini/hiview_log_limit.o
> [11/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_watchdog.o
> [12/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_partition.o
> [13/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_i2s.o
> [14/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_i2c.o
> [15/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_pwm.o
> [16/197] STAMP obj/build/lite/ndk.stamp
> [17/197] cross compiler obj/base/hiviewdfx/services/hiview_lite/hiview_service.o
> [18/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_uart.o
> [19/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_spi.o
> [20/197] cross compiler obj/base/hiviewdfx/utils/lite/hiview_file.o
> [21/197] cross compiler obj/base/hiviewdfx/utils/lite/hiview_cache.o
> [22/197] AR libs/libhiview_lite.a
> [23/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_sdio.o
> [24/197] cross compiler obj/base/hiviewdfx/frameworks/hilog_lite/mini/hiview_log.o
> [25/197] cross compiler obj/base/hiviewdfx/utils/lite/hiview_util.o
> [26/197] cross compiler obj/base/startup/services/bootstrap_lite/source/bootstrap_service.o
> [27/197] AR libs/libcommon_lite.a
> [28/197] cross compiler obj/base/iot_hardware/frameworks/wifiiot_lite/src/wifiiot_at.o
> [29/197] AR libs/libiothardware.a
> [30/197] STAMP obj/base/iot_hardware/frameworks/wifiiot_lite/src/iothardware_ndk.stamp
> [31/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/key_agreement/key_agreement.o
> [32/197] cross compiler obj/base/hiviewdfx/frameworks/hilog_lite/mini/hiview_output_log.o
> [33/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/key_agreement/key_agreement_client.o
> [34/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/json/jsonutil.o
> [35/197] AR libs/libhilog_lite.a
> [36/197] STAMP obj/base/hiviewdfx/frameworks/hilog_lite/mini/hilog_lite_ndk.stamp
> [37/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/auth_info/auth_info.o
> [38/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/auth_info/exchange_auth_info.o
> [39/197] cross compiler obj/foundation/communication/services/softbus_lite/authmanager/source/msg_get_deviceid.o
> [40/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/auth_info/add_auth_info.o
> [41/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/key_agreement/key_agreement_server.o
> [42/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/huks_adapter/huks_adapter.o
> [43/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/json/commonutil.o
> [44/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/key_agreement/sec_clone_server.o
> [45/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/auth_info/remove_auth_info_client.o
> [46/197] cross compiler obj/foundation/communication/services/softbus_lite/authmanager/source/auth_interface.o
> [47/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/auth_info/add_auth_info_client.o
> [48/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/auth_info/exchange_auth_info_client.o
> [49/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/add_auth_info_request.o
> [50/197] cross compiler obj/foundation/communication/services/softbus_lite/authmanager/source/auth_conn.o
> [51/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/add_auth_info_data.o
> [52/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/log/log.o
> [53/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/add_auth_info_response.o
> [54/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/key_agreement/sts_client.o
> [55/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/key_agreement/pake_client.o
> [56/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/hichain.o
> [57/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/key_agreement/pake_server.o
> [58/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/rmv_auth_info_data.o
> [59/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/schedule/build_object.o
> [60/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/key_agreement/sts_server.o
> [61/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/inform_message.o
> [62/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/key_agreement_version.o
> [63/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/auth_ack_response.o
> [64/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/auth_start_response.o
> [65/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/pake_client_confirm.o
> [66/197] STAMP obj/base/startup/frameworks/syspara_lite/token/token_notes.stamp
> [67/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/auth_ack_request.o
> [68/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/schedule/distribution.o
> [69/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/import_add_auth_data.o
> [70/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/rmv_auth_info_request.o
> [71/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/auth_start_request.o
> [72/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/exchange_response.o
> [73/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/pake_server_confirm.o
> [74/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/rmv_auth_info_response.o
> [75/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/exchange_auth_data.o
> [76/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/pake_request.o
> [77/197] cross compiler obj/base/startup/services/bootstrap_lite/source/system_init.o
> [78/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/sec_clone_data.o
> [79/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/pake_response.o
> [80/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/exchange_request.o
> [81/197] AR libs/libbootstrap.a
> [82/197] cross compiler obj/base/startup/frameworks/syspara_lite/token/src/token_impl_hal/token.o
> [83/197] cross compiler obj/base/security/frameworks/hichainsdk_lite/source/struct/parsedata.o
> [84/197] cross compiler obj/base/startup/frameworks/syspara_lite/parameter/src/parameter_common.o
> [85/197] cross compiler obj/base/startup/frameworks/syspara_lite/parameter/src/param_impl_hal/param_impl_hal.o
> [86/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/communication/broadcast/source/pub_sub_feature.o
> [87/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/adapter/cmsis/memory_adapter.o
> [88/197] AR libs/libhichainsdk.a
> [89/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/communication/broadcast/source/broadcast_service.o
> [90/197] STAMP obj/base/security/frameworks/hichainsdk_lite/hichainsdk.stamp
> [91/197] cross compiler obj/foundation/communication/services/softbus_lite/discovery/coap/source/coap_adapter.o
> [92/197] cross compiler obj/foundation/communication/services/softbus_lite/trans_service/source/libdistbus/tcp_session.o
> [93/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/communication/broadcast/source/pub_sub_implement.o
> [94/197] cross compiler obj/foundation/communication/services/softbus_lite/trans_service/source/utils/message.o
> [95/197] cross compiler obj/foundation/communication/services/softbus_lite/authmanager/source/bus_manager.o
> [96/197] cross compiler obj/foundation/communication/services/softbus_lite/trans_service/source/libdistbus/trans_lock.o
> [97/197] cross compiler obj/foundation/communication/services/softbus_lite/authmanager/source/wifi_auth_manager.o
> [98/197] cross compiler obj/foundation/communication/services/softbus_lite/discovery/discovery_service/source/common_info_manager.o
> [99/197] cross compiler obj/foundation/communication/services/softbus_lite/discovery/discovery_service/source/discovery_service.o
> [100/197] AR libs/libbroadcast.a
> [101/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/registry/service_registry.o
> [102/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/adapter/cmsis/queue_adapter.o
> [103/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/source/iunknown.o
> [104/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/adapter/cmsis/thread_adapter.o
> [105/197] cross compiler obj/foundation/communication/services/softbus_lite/trans_service/source/libdistbus/tcp_session_manager.o
> [106/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/adapter/cmsis/time_adapter.o
> [107/197] AR libs/libsamgr_adapter.a
> [108/197] cross compiler obj/foundation/communication/services/softbus_lite/trans_service/source/utils/aes_gcm.o
> [109/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/source/feature.o
> [110/197] STAMP obj/test/xts/acts/acts_compoment.stamp
> [111/197] STAMP obj/test/xts/tools/tools.stamp
> [112/197] STAMP obj/third_party/cJSON/cjson_shared.stamp
> [113/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/source/common.o
> [114/197] AR libs/libauthmanager.a
> [115/197] cross compiler obj/foundation/communication/services/softbus_lite/discovery/coap/source/nstackx_device.o
> [116/197] cross compiler obj/foundation/communication/services/softbus_lite/discovery/coap/source/json_payload.o
> [117/197] cross compiler obj/foundation/communication/services/softbus_lite/discovery/coap/source/coap_socket.o
> [118/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/source/samgr_lite.o
> [119/197] cross compiler obj/foundation/communication/services/softbus_lite/discovery/coap/source/nstackx_common.o
> [120/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/source/service.o
> [121/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_watchdog.o
> [122/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/source/message.o
> [123/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_partition.o
> [124/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_at.o
> [125/197] cross compiler obj/foundation/distributedschedule/services/samgr_lite/samgr/source/task_manager.o
> [126/197] cross compiler obj/kernel/liteos_m/components/kal/src/kal.o
> [127/197] cross compiler obj/utils/native/lite/file/src/file_impl_hal/file.o
> [128/197] cross compiler obj/utils/native/lite/kv_store/src/kvstore_common/kvstore_common.o
> [129/197] cross compiler obj/utils/native/lite/kv_store/src/kvstore_impl_hal/kv_store.o
> [130/197] AR libs/libkal.a
> [131/197] AR libs/libsamgr_source.a
> [132/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_uart.o
> [133/197] AR libs/libutils_kv_store.a
> [134/197] STAMP obj/utils/native/lite/kv_store/kv_store.stamp
> [135/197] AR libs/libsamgr.a
> [136/197] cross compiler obj/third_party/cJSON/cJSON_Utils.o
> [137/197] STAMP obj/foundation/distributedschedule/services/samgr_lite/samgr.stamp
> [138/197] STAMP obj/foundation/distributedschedule/services/samgr_lite/samgr_lite_ndk.stamp
> [139/197] cross compiler obj/foundation/communication/services/softbus_lite/discovery/discovery_service/source/coap_service.o
> [140/197] cross compiler obj/foundation/communication/services/softbus_lite/os_adapter/source/L0/os_adapter.o
> [141/197] cross compiler obj/third_party/cJSON/cJSON.o
> [142/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_spi.o
> [143/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_pwm.o
> [144/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_sdio.o
> [145/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_kal.o
> [146/197] AR libs/libcjson_static.a
> [147/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_i2s.o
> [148/197] cross compiler obj/vendor/huawei/wifi-iot/hals/utils/token/hal_token.o
> [149/197] STAMP obj/third_party/cJSON/cjson_ndk.stamp
> [150/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_i2c.o
> [151/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_adc.o
> [152/197] cross compiler obj/foundation/communication/services/softbus_lite/trans_service/source/utils/tcp_socket.o
> [153/197] AR libs/libhal_token_static.a
> [154/197] AR libs/libtoken_static.a
> [155/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_lowpower.o
> [156/197] STAMP obj/base/startup/frameworks/syspara_lite/token/token.stamp
> [157/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_gpio.o
> [158/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_reset.o
> [159/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/utils/file/src/hal_file.o
> [160/197] cross compiler obj/foundation/communication/services/softbus_lite/trans_service/source/libdistbus/auth_conn_manager.o
> [161/197] cross compiler obj/kernel/liteos_m/components/cmsis/cmsis_liteos.o
> [162/197] AR libs/libhal_file_static.a
> [163/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/iot_hardware/wifiiot_lite/hal_wifiiot_flash.o
> [164/197] AR libs/libcmsis.a
> [165/197] STAMP obj/vendor/hisi/hi3861/hi3861/sdk.stamp
> [166/197] AR libs/libnative_file.a
> [167/197] AR libs/libtrans_service.a
> [168/197] STAMP obj/vendor/hisi/hi3861/hi3861/wifiiot_sdk.stamp
> [169/197] STAMP obj/utils/native/lite/file/file.stamp
> [170/197] STAMP obj/foundation/communication/services/softbus_lite/trans_service_ndk.stamp
> [171/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/communication/wifi_lite/wifiservice/source/wifi_device.o
> [172/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/communication/wifi_lite/wifiservice/source/wifi_device_util.o
> [173/197] AR libs/libhal_iothardware.a
> [174/197] STAMP obj/base/iot_hardware/frameworks/wifiiot_lite/iothardware.stamp
> [175/197] cross compiler obj/vendor/hisi/hi3861/hi3861_adapter/hals/communication/wifi_lite/wifiservice/source/wifi_hotspot.o
> [176/197] AR libs/libwifiservice.a
> [177/197] STAMP obj/foundation/communication/frameworks/wifi_lite/wifi.stamp
> [178/197] STAMP obj/vendor/hisi/hi3861/hi3861_adapter/hals/communication/wifi_lite/wifiservice/wifiservice_ndk.stamp
> [179/197] cross compiler obj/vendor/huawei/wifi-iot/hals/utils/sys_param/hal_sys_param.o
> [180/197] AR libs/libhal_sysparam.a
> [181/197] AR libs/libsysparam.a
> [182/197] STAMP obj/base/startup/frameworks/syspara_lite/parameter/parameter_notes.stamp
> [183/197] STAMP obj/base/startup/frameworks/syspara_lite/parameter/parameter.stamp
> [184/197] cross compiler obj/foundation/communication/services/softbus_lite/discovery/coap/source/coap_discover.o
> [185/197] AR libs/libdiscovery.a
> [186/197] STAMP obj/foundation/communication/services/softbus_lite/discovery_ndk.stamp
> [187/197] STAMP obj/foundation/communication/services/softbus_lite/softbus.stamp
> [188/197] STAMP obj/foundation/communication/services/softbus_lite/softbus_lite_ndk.stamp
> [189/197] ACTION //test/xdevice:xdevice(//build/lite/toolchain:linux_x86_64_riscv32_gcc)
> running install
> running bdist_egg
> running egg_info
> creating src/xdevice.egg-info
> writing src/xdevice.egg-info/PKG-INFO
> writing dependency_links to src/xdevice.egg-info/dependency_links.txt
> writing entry points to src/xdevice.egg-info/entry_points.txt
> writing top-level names to src/xdevice.egg-info/top_level.txt
> writing manifest file 'src/xdevice.egg-info/SOURCES.txt'
> reading manifest file 'src/xdevice.egg-info/SOURCES.txt'
> writing manifest file 'src/xdevice.egg-info/SOURCES.txt'
> installing library code to build/bdist.linux-x86_64/egg
> running install_lib
> running build_py
> creating build
> creating build/lib
> creating build/lib/xdevice
> copying src/xdevice/variables.py -> build/lib/xdevice
> copying src/xdevice/__init__.py -> build/lib/xdevice
> copying src/xdevice/__main__.py -> build/lib/xdevice
> creating build/lib/xdevice/_core
> copying src/xdevice/_core/common.py -> build/lib/xdevice/_core
> copying src/xdevice/_core/constants.py -> build/lib/xdevice/_core
> copying src/xdevice/_core/exception.py -> build/lib/xdevice/_core
> copying src/xdevice/_core/interface.py -> build/lib/xdevice/_core
> copying src/xdevice/_core/logger.py -> build/lib/xdevice/_core
> copying src/xdevice/_core/plugin.py -> build/lib/xdevice/_core
> copying src/xdevice/_core/utils.py -> build/lib/xdevice/_core
> copying src/xdevice/_core/__init__.py -> build/lib/xdevice/_core
> creating build/lib/xdevice/_core/build
> copying src/xdevice/_core/build/__init__.py -> build/lib/xdevice/_core/build
> creating build/lib/xdevice/_core/command
> copying src/xdevice/_core/command/console.py -> build/lib/xdevice/_core/command
> copying src/xdevice/_core/command/__init__.py -> build/lib/xdevice/_core/command
> creating build/lib/xdevice/_core/config
> copying src/xdevice/_core/config/config_manager.py -> build/lib/xdevice/_core/config
> copying src/xdevice/_core/config/resource_manager.py -> build/lib/xdevice/_core/config
> copying src/xdevice/_core/config/__init__.py -> build/lib/xdevice/_core/config
> creating build/lib/xdevice/_core/driver
> copying src/xdevice/_core/driver/device_test.py -> build/lib/xdevice/_core/driver
> copying src/xdevice/_core/driver/drivers_lite.py -> build/lib/xdevice/_core/driver
> copying src/xdevice/_core/driver/parser_lite.py -> build/lib/xdevice/_core/driver
> copying src/xdevice/_core/driver/__init__.py -> build/lib/xdevice/_core/driver
> creating build/lib/xdevice/_core/environment
> copying src/xdevice/_core/environment/device_lite.py -> build/lib/xdevice/_core/environment
> copying src/xdevice/_core/environment/dmlib_lite.py -> build/lib/xdevice/_core/environment
> copying src/xdevice/_core/environment/manager_env.py -> build/lib/xdevice/_core/environment
> copying src/xdevice/_core/environment/manager_lite.py -> build/lib/xdevice/_core/environment
> copying src/xdevice/_core/environment/__init__.py -> build/lib/xdevice/_core/environment
> creating build/lib/xdevice/_core/executor
> copying src/xdevice/_core/executor/concurrent.py -> build/lib/xdevice/_core/executor
> copying src/xdevice/_core/executor/listener.py -> build/lib/xdevice/_core/executor
> copying src/xdevice/_core/executor/request.py -> build/lib/xdevice/_core/executor
> copying src/xdevice/_core/executor/scheduler.py -> build/lib/xdevice/_core/executor
> copying src/xdevice/_core/executor/source.py -> build/lib/xdevice/_core/executor
> copying src/xdevice/_core/executor/__init__.py -> build/lib/xdevice/_core/executor
> creating build/lib/xdevice/_core/report
> copying src/xdevice/_core/report/encrypt.py -> build/lib/xdevice/_core/report
> copying src/xdevice/_core/report/reporter_helper.py -> build/lib/xdevice/_core/report
> copying src/xdevice/_core/report/result_reporter.py -> build/lib/xdevice/_core/report
> copying src/xdevice/_core/report/suite_reporter.py -> build/lib/xdevice/_core/report
> copying src/xdevice/_core/report/__init__.py -> build/lib/xdevice/_core/report
> copying src/xdevice/_core/report/__main__.py -> build/lib/xdevice/_core/report
> creating build/lib/xdevice/_core/testkit
> copying src/xdevice/_core/testkit/json_parser.py -> build/lib/xdevice/_core/testkit
> copying src/xdevice/_core/testkit/kit_lite.py -> build/lib/xdevice/_core/testkit
> copying src/xdevice/_core/testkit/uikit_lite.py -> build/lib/xdevice/_core/testkit
> copying src/xdevice/_core/testkit/__init__.py -> build/lib/xdevice/_core/testkit
> creating build/lib/xdevice/_core/resource
> creating build/lib/xdevice/_core/resource/config
> copying src/xdevice/_core/resource/config/user_config.xml -> build/lib/xdevice/_core/resource/config
> creating build/lib/xdevice/_core/resource/template
> copying src/xdevice/_core/resource/template/report.html -> build/lib/xdevice/_core/resource/template
> creating build/bdist.linux-x86_64
> creating build/bdist.linux-x86_64/egg
> creating build/bdist.linux-x86_64/egg/xdevice
> copying build/lib/xdevice/variables.py -> build/bdist.linux-x86_64/egg/xdevice
> creating build/bdist.linux-x86_64/egg/xdevice/_core
> creating build/bdist.linux-x86_64/egg/xdevice/_core/build
> copying build/lib/xdevice/_core/build/__init__.py -> build/bdist.linux-x86_64/egg/xdevice/_core/build
> creating build/bdist.linux-x86_64/egg/xdevice/_core/command
> copying build/lib/xdevice/_core/command/console.py -> build/bdist.linux-x86_64/egg/xdevice/_core/command
> copying build/lib/xdevice/_core/command/__init__.py -> build/bdist.linux-x86_64/egg/xdevice/_core/command
> copying build/lib/xdevice/_core/common.py -> build/bdist.linux-x86_64/egg/xdevice/_core
> creating build/bdist.linux-x86_64/egg/xdevice/_core/config
> copying build/lib/xdevice/_core/config/config_manager.py -> build/bdist.linux-x86_64/egg/xdevice/_core/config
> copying build/lib/xdevice/_core/config/resource_manager.py -> build/bdist.linux-x86_64/egg/xdevice/_core/config
> copying build/lib/xdevice/_core/config/__init__.py -> build/bdist.linux-x86_64/egg/xdevice/_core/config
> copying build/lib/xdevice/_core/constants.py -> build/bdist.linux-x86_64/egg/xdevice/_core
> creating build/bdist.linux-x86_64/egg/xdevice/_core/driver
> copying build/lib/xdevice/_core/driver/device_test.py -> build/bdist.linux-x86_64/egg/xdevice/_core/driver
> copying build/lib/xdevice/_core/driver/drivers_lite.py -> build/bdist.linux-x86_64/egg/xdevice/_core/driver
> copying build/lib/xdevice/_core/driver/parser_lite.py -> build/bdist.linux-x86_64/egg/xdevice/_core/driver
> copying build/lib/xdevice/_core/driver/__init__.py -> build/bdist.linux-x86_64/egg/xdevice/_core/driver
> creating build/bdist.linux-x86_64/egg/xdevice/_core/environment
> copying build/lib/xdevice/_core/environment/device_lite.py -> build/bdist.linux-x86_64/egg/xdevice/_core/environment
> copying build/lib/xdevice/_core/environment/dmlib_lite.py -> build/bdist.linux-x86_64/egg/xdevice/_core/environment
> copying build/lib/xdevice/_core/environment/manager_env.py -> build/bdist.linux-x86_64/egg/xdevice/_core/environment
> copying build/lib/xdevice/_core/environment/manager_lite.py -> build/bdist.linux-x86_64/egg/xdevice/_core/environment
> copying build/lib/xdevice/_core/environment/__init__.py -> build/bdist.linux-x86_64/egg/xdevice/_core/environment
> copying build/lib/xdevice/_core/exception.py -> build/bdist.linux-x86_64/egg/xdevice/_core
> creating build/bdist.linux-x86_64/egg/xdevice/_core/executor
> copying build/lib/xdevice/_core/executor/concurrent.py -> build/bdist.linux-x86_64/egg/xdevice/_core/executor
> copying build/lib/xdevice/_core/executor/listener.py -> build/bdist.linux-x86_64/egg/xdevice/_core/executor
> copying build/lib/xdevice/_core/executor/request.py -> build/bdist.linux-x86_64/egg/xdevice/_core/executor
> copying build/lib/xdevice/_core/executor/scheduler.py -> build/bdist.linux-x86_64/egg/xdevice/_core/executor
> copying build/lib/xdevice/_core/executor/source.py -> build/bdist.linux-x86_64/egg/xdevice/_core/executor
> copying build/lib/xdevice/_core/executor/__init__.py -> build/bdist.linux-x86_64/egg/xdevice/_core/executor
> copying build/lib/xdevice/_core/interface.py -> build/bdist.linux-x86_64/egg/xdevice/_core
> copying build/lib/xdevice/_core/logger.py -> build/bdist.linux-x86_64/egg/xdevice/_core
> copying build/lib/xdevice/_core/plugin.py -> build/bdist.linux-x86_64/egg/xdevice/_core
> creating build/bdist.linux-x86_64/egg/xdevice/_core/report
> copying build/lib/xdevice/_core/report/encrypt.py -> build/bdist.linux-x86_64/egg/xdevice/_core/report
> copying build/lib/xdevice/_core/report/reporter_helper.py -> build/bdist.linux-x86_64/egg/xdevice/_core/report
> copying build/lib/xdevice/_core/report/result_reporter.py -> build/bdist.linux-x86_64/egg/xdevice/_core/report
> copying build/lib/xdevice/_core/report/suite_reporter.py -> build/bdist.linux-x86_64/egg/xdevice/_core/report
> copying build/lib/xdevice/_core/report/__init__.py -> build/bdist.linux-x86_64/egg/xdevice/_core/report
> copying build/lib/xdevice/_core/report/__main__.py -> build/bdist.linux-x86_64/egg/xdevice/_core/report
> creating build/bdist.linux-x86_64/egg/xdevice/_core/resource
> creating build/bdist.linux-x86_64/egg/xdevice/_core/resource/config
> copying build/lib/xdevice/_core/resource/config/user_config.xml -> build/bdist.linux-x86_64/egg/xdevice/_core/resource/config
> creating build/bdist.linux-x86_64/egg/xdevice/_core/resource/template
> copying build/lib/xdevice/_core/resource/template/report.html -> build/bdist.linux-x86_64/egg/xdevice/_core/resource/template
> creating build/bdist.linux-x86_64/egg/xdevice/_core/testkit
> copying build/lib/xdevice/_core/testkit/json_parser.py -> build/bdist.linux-x86_64/egg/xdevice/_core/testkit
> copying build/lib/xdevice/_core/testkit/kit_lite.py -> build/bdist.linux-x86_64/egg/xdevice/_core/testkit
> copying build/lib/xdevice/_core/testkit/uikit_lite.py -> build/bdist.linux-x86_64/egg/xdevice/_core/testkit
> copying build/lib/xdevice/_core/testkit/__init__.py -> build/bdist.linux-x86_64/egg/xdevice/_core/testkit
> copying build/lib/xdevice/_core/utils.py -> build/bdist.linux-x86_64/egg/xdevice/_core
> copying build/lib/xdevice/_core/__init__.py -> build/bdist.linux-x86_64/egg/xdevice/_core
> copying build/lib/xdevice/__init__.py -> build/bdist.linux-x86_64/egg/xdevice
> copying build/lib/xdevice/__main__.py -> build/bdist.linux-x86_64/egg/xdevice
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/variables.py to variables.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/build/__init__.py to __init__.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/command/console.py to console.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/command/__init__.py to __init__.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/common.py to common.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/config/config_manager.py to config_manager.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/config/resource_manager.py to resource_manager.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/config/__init__.py to __init__.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/constants.py to constants.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/driver/device_test.py to device_test.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/driver/drivers_lite.py to drivers_lite.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/driver/parser_lite.py to parser_lite.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/driver/__init__.py to __init__.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/environment/device_lite.py to device_lite.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/environment/dmlib_lite.py to dmlib_lite.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/environment/manager_env.py to manager_env.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/environment/manager_lite.py to manager_lite.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/environment/__init__.py to __init__.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/exception.py to exception.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/executor/concurrent.py to concurrent.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/executor/listener.py to listener.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/executor/request.py to request.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/executor/scheduler.py to scheduler.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/executor/source.py to source.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/executor/__init__.py to __init__.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/interface.py to interface.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/logger.py to logger.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/plugin.py to plugin.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/report/encrypt.py to encrypt.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/report/reporter_helper.py to reporter_helper.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/report/result_reporter.py to result_reporter.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/report/suite_reporter.py to suite_reporter.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/report/__init__.py to __init__.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/report/__main__.py to __main__.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/testkit/json_parser.py to json_parser.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/testkit/kit_lite.py to kit_lite.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/testkit/uikit_lite.py to uikit_lite.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/testkit/__init__.py to __init__.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/utils.py to utils.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/_core/__init__.py to __init__.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/__init__.py to __init__.cpython-38.pyc
> byte-compiling build/bdist.linux-x86_64/egg/xdevice/__main__.py to __main__.cpython-38.pyc
> creating build/bdist.linux-x86_64/egg/EGG-INFO
> copying src/xdevice.egg-info/PKG-INFO -> build/bdist.linux-x86_64/egg/EGG-INFO
> copying src/xdevice.egg-info/SOURCES.txt -> build/bdist.linux-x86_64/egg/EGG-INFO
> copying src/xdevice.egg-info/dependency_links.txt -> build/bdist.linux-x86_64/egg/EGG-INFO
> copying src/xdevice.egg-info/entry_points.txt -> build/bdist.linux-x86_64/egg/EGG-INFO
> copying src/xdevice.egg-info/not-zip-safe -> build/bdist.linux-x86_64/egg/EGG-INFO
> copying src/xdevice.egg-info/top_level.txt -> build/bdist.linux-x86_64/egg/EGG-INFO
> creating dist
> creating 'dist/xdevice-0.0.0-py3.8.egg' and adding 'build/bdist.linux-x86_64/egg' to it
> removing 'build/bdist.linux-x86_64/egg' (and everything under it)
> Processing xdevice-0.0.0-py3.8.egg
> creating /root/.local/lib/python3.8/site-packages/xdevice-0.0.0-py3.8.egg
> Extracting xdevice-0.0.0-py3.8.egg to /root/.local/lib/python3.8/site-packages
> Adding xdevice 0.0.0 to easy-install.pth file
> Installing xdevice script to /root/.local/bin
> Installing xdevice_report script to /root/.local/bin
> 
> Installed /root/.local/lib/python3.8/site-packages/xdevice-0.0.0-py3.8.egg
> Processing dependencies for xdevice==0.0.0
> Finished processing dependencies for xdevice==0.0.0
> [190/197] STAMP obj/test/xdevice/xdevice.stamp
> [191/197] ACTION //test/xts/acts:acts(//build/lite/toolchain:linux_x86_64_riscv32_gcc)
> [192/197] STAMP obj/test/xts/acts/acts.stamp
> [193/197] STAMP obj/build/lite/ohos.stamp
> [194/197] ACTION //build/lite:gen_rootfs(//build/lite/toolchain:linux_x86_64_riscv32_gcc)
> [195/197] STAMP obj/build/lite/gen_rootfs.stamp
> 
> [196/197] ACTION //vendor/hisi/hi3861/hi3861:run_wifiiot_scons(//build/lite/toolchain:linux_x86_64_riscv32_gcc)
> patching file disk/part_dos.c
> patching file fs/ext4/ext4fs.c
> patching file fs/ext4/ext4fs.c
> Hunk #1 succeeded at 288 (offset 2 lines).
> patching file fs/ext4/ext4fs.c
> patching file net/net.c
> Hunk #1 succeeded at 1252 (offset -12 lines).
> patching file net/nfs.c
> patching file net/nfs.c
> patching file net/nfs.c
> patching file net/nfs.c
> Hunk #1 succeeded at 742 (offset 10 lines).
> patching file lib/crc32.c
> patching file lib/lzma/LzmaDec.c
> patching file lib/lzma/LzmaTools.c
> patching file lib/lzma/LzmaTools.h
> patching file lib/lzma/Types.h
> patching file lib/SConscript
> patching file SConscript
> /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/build/scripts/hi_config_parser.py:85: SyntaxWarning: "is" with a literal. Did you mean "=="?
>   if option is '':
> execute ota_builder with python...
> Compiling platform/drivers/uart/hi_uart.c
> Compiling platform/drivers/uart/uart.c
> Compiling platform/drivers/uart/uart_drv.c
> Archiving build/build_tmp/libs/platform/drivers/libuart.a
> riscv32-unknown-elf-ranlib build/build_tmp/libs/platform/drivers/libuart.a
> Compiling platform/drivers/adc/hi_adc.c
> Archiving build/build_tmp/libs/platform/drivers/libadc.a
> riscv32-unknown-elf-ranlib build/build_tmp/libs/platform/drivers/libadc.a
> Compiling platform/drivers/tsensor/hi_tsensor_pm.c
> Archiving build/build_tmp/libs/platform/drivers/libtsensor.a
> riscv32-unknown-elf-ranlib build/build_tmp/libs/platform/drivers/libtsensor.a
> Compiling platform/system/cfg/sal_cfg.c
> Archiving build/build_tmp/libs/platform/system/libcfg.a
> riscv32-unknown-elf-ranlib build/build_tmp/libs/platform/system/libcfg.a
> Compiling platform/system/partition_table/flash_partition_table.c
> Archiving build/build_tmp/libs/platform/system/libparttab.a
> riscv32-unknown-elf-ranlib build/build_tmp/libs/platform/system/libparttab.a
> Compiling platform/system/upg/kernel_crypto.c
> Compiling platform/system/upg/upg_check_boot_bin.c
> Compiling platform/system/upg/upg_check_file.c
> Compiling platform/system/upg/upg_check_secure.c
> Compiling platform/system/upg/upg_common.c
> Compiling platform/system/upg/upg_start_up.c
> Compiling platform/system/upg/upg_user_verify.c
> Archiving build/build_tmp/libs/platform/system/libupg.a
> riscv32-unknown-elf-ranlib build/build_tmp/libs/platform/system/libupg.a
> Compiling components/at/src/at.c
> Compiling components/at/src/at_cmd.c
> Compiling components/at/src/at_demo_hks.c
> Compiling components/at/src/at_general.c
> Compiling components/at/src/at_hipriv.c
> Compiling components/at/src/at_io.c
> Compiling components/at/src/at_lowpower.c
> Compiling components/at/src/at_parse.c
> Compiling components/at/src/at_printf.c
> Compiling components/at/src/at_wifi.c
> Compiling components/at/src/hi_at.c
> Archiving build/build_tmp/libs/components/at/libat.a
> riscv32-unknown-elf-ranlib build/build_tmp/libs/components/at/libat.a
> Compiling app/wifiiot_app/init/app_io_init.c
> Compiling app/wifiiot_app/src/app_demo_upg_verify.c
> Compiling app/wifiiot_app/src/app_main.c
> Archiving build/build_tmp/libs/app/wifiiot_app/libwifiiot_app.a
> riscv32-unknown-elf-ranlib build/build_tmp/libs/app/wifiiot_app/libwifiiot_app.a
> Compiling boot/commonboot/efuse/efuse_drv.c
> Compiling boot/commonboot/flash/flash_hw_process_flashboot.c
> Compiling boot/flashboot/common/nvm/hi_nvm.c
> Compiling boot/flashboot/common/partition_table/boot_partition_table.c
> Compiling boot/flashboot/drivers/efuse/efuse.c
> Compiling boot/flashboot/drivers/flash/hi_flashboot_flash.c
> Compiling boot/flashboot/drivers/gpio/hi_flashboot_gpio.c
> Compiling boot/flashboot/drivers/io/hi_flashboot_io.c
> Compiling boot/flashboot/drivers/lsadc/adc_drv.c
> Compiling boot/flashboot/lzmaram/lzmaram.c
> Compiling boot/flashboot/secure/crypto.c
> Compiling boot/flashboot/startup/main.c
> riscv32-unknown-elf-gcc -mabi=ilp32 -march=rv32imc -x assembler-with-cpp -Os -Wall -Werror -nostdinc -fno-common -DARCH_RISCV -DLOS_COMPILE_LDM -DHI_BOARD_ASIC -DCONFIG_COMPRESSION_OTA_SUPPORT -DCONFIG_CHIP_PKT_32K -Iboot/flashboot/fixed/include -Iboot/flashboot/upg -Iboot/flashboot/include -Iboot/flashboot/drivers/lsadc -Iboot/flashboot/drivers/efuse -Iboot/flashboot/include/lzma -Iboot/flashboot/drivers/gpio -Iboot/flashboot/drivers/io -Ithird_party/u-boot-v2019.07/u-boot-v2019.07/lib/lzma -Iboot/flashboot/secure -Iboot/commonboot -c -o build/build_tmp/objs/flashboot/startup/riscv_init_flashboot.o boot/flashboot/startup/riscv_init_flashboot.S
> Compiling boot/flashboot/startup/stack_protect.c
> Compiling third_party/u-boot-v2019.07/u-boot-v2019.07/lib/crc32.c
> Compiling third_party/u-boot-v2019.07/u-boot-v2019.07/lib/lzma/LzmaDec.c
> Compiling third_party/u-boot-v2019.07/u-boot-v2019.07/lib/lzma/LzmaTools.c
> Compiling boot/flashboot/upg/boot_start.c
> Compiling boot/flashboot/upg/boot_upg_check.c
> Compiling boot/flashboot/upg/boot_upg_check_secure.c
> Compiling boot/flashboot/upg/boot_upg_common.c
> Compiling boot/flashboot/upg/boot_upg_kernel.c
> Compiling boot/flashboot/upg/boot_upg_start_up.c
> Compiling boot/flashboot/upg/boot_upg_tool.c
> riscv32-unknown-elf-ld -nostdlib -nostartfiles -static --gc-sections -T/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/build/link/flashboot_sha256.lds -Lbuild/libs -Lbuild/libs/boot_libs build/build_tmp/objs/flashboot/boot/commonboot/efuse/efuse_drv.o build/build_tmp/objs/flashboot/boot/commonboot/flash/flash_hw_process_flashboot.o build/build_tmp/objs/flashboot/common/nvm/hi_nvm.o build/build_tmp/objs/flashboot/common/partition_table/boot_partition_table.o build/build_tmp/objs/flashboot/drivers/efuse/efuse.o build/build_tmp/objs/flashboot/drivers/flash/hi_flashboot_flash.o build/build_tmp/objs/flashboot/drivers/gpio/hi_flashboot_gpio.o build/build_tmp/objs/flashboot/drivers/io/hi_flashboot_io.o build/build_tmp/objs/flashboot/drivers/lsadc/adc_drv.o build/build_tmp/objs/flashboot/lzmaram/lzmaram.o build/build_tmp/objs/flashboot/secure/crypto.o build/build_tmp/objs/flashboot/startup/main.o build/build_tmp/objs/flashboot/startup/riscv_init_flashboot.o build/build_tmp/objs/flashboot/startup/stack_protect.o build/build_tmp/objs/flashboot/third_party/u-boot-v2019.07/u-boot-v2019.07/lib/crc32.o build/build_tmp/objs/flashboot/third_party/u-boot-v2019.07/u-boot-v2019.07/lib/lzma/LzmaDec.o build/build_tmp/objs/flashboot/third_party/u-boot-v2019.07/u-boot-v2019.07/lib/lzma/LzmaTools.o build/build_tmp/objs/flashboot/upg/boot_start.o build/build_tmp/objs/flashboot/upg/boot_upg_check.o build/build_tmp/objs/flashboot/upg/boot_upg_check_secure.o build/build_tmp/objs/flashboot/upg/boot_upg_common.o build/build_tmp/objs/flashboot/upg/boot_upg_kernel.o build/build_tmp/objs/flashboot/upg/boot_upg_start_up.o build/build_tmp/objs/flashboot/upg/boot_upg_tool.o -o build/build_tmp/cache/flash_boot.elf --start-group --end-group
> riscv32-unknown-elf-objcopy -Obinary -R .rom.text -R .rom.code.text -R .u_boot_cmd -R .rom.data -R .rom.code.data -R .rom.bss -R .rom.code.bss -S build/build_tmp/cache/flash_boot.elf build/build_tmp/cache/hi_flash_boot.bin
> cleanup(["build/build_tmp/cache/hi_flash_boot.bin"], ["build/build_tmp/cache/flash_boot.elf"])
> tools/sign_tool/sign_tool -i build/build_tmp/cache/hi_flash_boot.bin -o output/bin/Hi3861_boot_signed.bin -n -toutput/bin/Hi3861_boot_signed_B.bin
> [input file]:        build/build_tmp/cache/hi_flash_boot.bin
> [output file]:       output/bin/Hi3861_boot_signed.bin
> [tail boot]:         output/bin/Hi3861_boot_signed_B.bin
> Sign non securtiy kernel success!
> cleanup(["output/bin/Hi3861_boot_signed.bin"], ["build/build_tmp/cache/hi_flash_boot.bin"])
> Compiling boot/commonboot/efuse/efuse_drv.c
> Compiling boot/commonboot/flash/flash_hw_process_flashboot.c
> Compiling boot/loaderboot/common/cmd_loop.c
> Compiling boot/loaderboot/common/efuse_opt.c
> Compiling boot/loaderboot/common/nvm/hi_nvm.c
> Compiling boot/loaderboot/common/partition_table/load_partition_table.c
> Compiling boot/loaderboot/common/transfer.c
> Compiling boot/loaderboot/drivers/efuse/efuse.c
> Compiling boot/loaderboot/drivers/flash/hi_loaderboot_flash.c
> Compiling boot/loaderboot/drivers/lsadc/adc_drv.c
> Compiling boot/loaderboot/secure/burn_file.c
> Compiling boot/loaderboot/secure/load_crypto.c
> Compiling boot/loaderboot/startup/main.c
> riscv32-unknown-elf-gcc -mabi=ilp32 -march=rv32imc -x assembler-with-cpp -Os -Wall -Werror -nostdinc -fno-common -DARCH_RISCV -DLOS_COMPILE_LDM -DHI_BOARD_ASIC -DCONFIG_COMPRESSION_OTA_SUPPORT -DCONFIG_CHIP_PKT_32K -Iboot/loaderboot/include -Iboot/loaderboot/fixed/include -Iboot/loaderboot/secure -Iboot/commonboot -c -o build/build_tmp/objs/loaderboot/startup/riscv_init_loaderboot.o boot/loaderboot/startup/riscv_init_loaderboot.S
> Compiling boot/loaderboot/startup/stack_protect.c
> Compiling third_party/u-boot-v2019.07/u-boot-v2019.07/lib/crc32.c
> Compiling third_party/u-boot-v2019.07/u-boot-v2019.07/lib/lzma/LzmaDec.c
> Compiling third_party/u-boot-v2019.07/u-boot-v2019.07/lib/lzma/LzmaTools.c
> riscv32-unknown-elf-ld -nostdlib -nostartfiles -static --gc-sections -T/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/build/link/loaderboot_sha256.lds -Lbuild/libs -Lbuild/libs/boot_libs build/build_tmp/objs/loaderboot/boot/commonboot/efuse/efuse_drv.o build/build_tmp/objs/loaderboot/boot/commonboot/flash/flash_hw_process_flashboot.o build/build_tmp/objs/loaderboot/common/cmd_loop.o build/build_tmp/objs/loaderboot/common/efuse_opt.o build/build_tmp/objs/loaderboot/common/nvm/hi_nvm.o build/build_tmp/objs/loaderboot/common/partition_table/load_partition_table.o build/build_tmp/objs/loaderboot/common/transfer.o build/build_tmp/objs/loaderboot/drivers/efuse/efuse.o build/build_tmp/objs/loaderboot/drivers/flash/hi_loaderboot_flash.o build/build_tmp/objs/loaderboot/drivers/lsadc/adc_drv.o build/build_tmp/objs/loaderboot/secure/burn_file.o build/build_tmp/objs/loaderboot/secure/load_crypto.o build/build_tmp/objs/loaderboot/startup/main.o build/build_tmp/objs/loaderboot/startup/riscv_init_loaderboot.o build/build_tmp/objs/loaderboot/startup/stack_protect.o build/build_tmp/objs/loaderboot/third_party/u-boot-v2019.07/u-boot-v2019.07/lib/crc32.o build/build_tmp/objs/loaderboot/third_party/u-boot-v2019.07/u-boot-v2019.07/lib/lzma/LzmaDec.o build/build_tmp/objs/loaderboot/third_party/u-boot-v2019.07/u-boot-v2019.07/lib/lzma/LzmaTools.o -o build/build_tmp/cache/loader_boot.elf --start-group --end-group
> riscv32-unknown-elf-objcopy -Obinary -R .rom.text -R .rom.code.text -R .u_boot_cmd -R .rom.data -R .rom.code.data -R .rom.bss -R .rom.code.bss -S build/build_tmp/cache/loader_boot.elf build/build_tmp/cache/hi_loader_boot.bin
> cleanup(["build/build_tmp/cache/hi_loader_boot.bin"], ["build/build_tmp/cache/loader_boot.elf"])
> tools/sign_tool/sign_tool -i build/build_tmp/cache/hi_loader_boot.bin -o output/bin/Hi3861_loader_signed.bin -n
> [input file]:        build/build_tmp/cache/hi_loader_boot.bin
> [output file]:       output/bin/Hi3861_loader_signed.bin
> Sign non securtiy kernel success!
> riscv32-unknown-elf-gcc -Iplatform/os/Huawei_LiteOS/kernel/include -Iconfig -DCONFIG_TEE_HUKS_SUPPORT -DCONFIG_CHIP_PKT_32K -DHI_BOARD_ASIC -DHI_ON_FLASH -E build/link/system_config.ld.S -o build/build_tmp/scripts/system_config.ld -P
> nvimg_builder(["build/build_tmp/scripts/system_config.ld"], ["build/link/system_config.ld.S"])
> product_name_list: ['sta']
> xml h file: /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/h_file/nv
> /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/out_nv_bin/sta
> app_subver_list: ['demo']
> current subver_name:demo
> root_dir: /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool
> mdm_xml: /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/xml_file/mss_nvi_db.xml
> HNV NAME:mss_nvi_db.xml
> nv_tool: /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/tools/nv/cdbm
> app_subver_temp_dir:/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/out_nv_bin/sta/nv/Hi3861_wifiiot_app/outside_demo
> make app_subver_temp_dir
> mdmxml:/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/xml_file/mss_nvi_db.xml
> src_xml_list: ['/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/xml_file/mss_nvi_db.xml']
> combin_xml:/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/out_nv_bin/sta/nv/Hi3861_wifiiot_app/mss_nvi_db.xml
> root_list [<Element 'HISTUDIO' at 0x7f6204c814f0>]
> hi_nv_modify_by_cfg
> cfg_file: nv
> 
> cmd_line= ('/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/tools/nv/cdbm', '/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/out_nv_bin/sta/nv/Hi3861_wifiiot_app/outside_demo/nv.xml', '/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/h_file/nv', '/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/out_nv_bin/sta/nv/Hi3861_wifiiot_app/outside_demo/nv')
> /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/out_nv_bin/sta/nv/Hi3861_wifiiot_app/outside_demo/nv.xml
> /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/h_file/nv
> /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/out_nv_bin/sta/nv/Hi3861_wifiiot_app/outside_demo/nv
> ===========Init HDB Start===========
> *********strDataTypeDefPath:/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/h_file/nv/../nv/nv_modem_struct_def.txt
> *********strDataTypeDefPath:/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/h_file/nv/../nv/nv_modem_struct_def.txt
> *********strDataTypeDefPath:/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/h_file/nv/../nv/nv_factory_struct_def.txt
> ===========Init HDB finish===========
> ===========Write NV Buffer To File===========
> ===========Write NV Buffer Finish===========
> RETURN VALUE:0
> dst_hnv= /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/out_nv_bin/sta/nv/hnv/Hi3861_wifiiot_app.hnv
> Factory NV total num:10
> NV_FILE_STRU :28
> Factory NV total size:824
> Normal NV total num:13
> NV_FILE_STRU :28
> Normal NV total size:766
> build hnv OK:/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/tools/nvtool/out_nv_bin/sta/nv/hnv/Hi3861_wifiiot_app.hnv
> ENDING
> riscv32-unknown-elf-gcc -Iplatform/os/Huawei_LiteOS/kernel/include -Iconfig -DCONFIG_TEE_HUKS_SUPPORT -DCONFIG_CHIP_PKT_32K -DHI_BOARD_ASIC -DHI_ON_FLASH -DFLASH_FIRM_START=4248512 -E build/link/link.ld.S -o build/build_tmp/scripts/link.lds -P
> riscv32-unknown-elf-ld -nostartfiles -nostdlib -static --gc-sections -L/home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/build/scripts/../../../../../huawei/hms/hilink/ohos/l0/hi3861/lib/wifi -L/home/tools/gcc_riscv32/bin/../lib/gcc/riscv32-unknown-elf/7.3.0 -Lbuild/build_tmp/libs/app/wifiiot_app -Lbuild/build_tmp/libs/components/at -Lbuild/build_tmp/libs/platform/drivers -Lbuild/build_tmp/libs/platform/system -Lbuild/build_tmp/scripts -Lbuild/libs -Lbuild/libs/hi3861/release/no_mesh -Lbuild/scripts -Lohos/libs -Tbuild/build_tmp/scripts/link.lds -Map=output/bin/Hi3861_wifiiot_app.map -o output/bin/Hi3861_wifiiot_app.out --start-group --no-whole-archive --whole-archive -lHwKeystoreSDK -ladc -lat -lauthmanager -lbootstrap -lbroadcast -lc_flash -lcfg -lcjson_static -lcmsis -lcommon_lite -lcpup -ldiag -ldiscovery -ldrv -lflash -lgcc -lgpio -lhal_file_static -lhal_iothardware -lhal_sysparam -lhal_token_static -lhichainsdk -lhilog_lite -lhiview_lite -lio -liothardware -liperf -lkal -llitekernel_flash -lltoswpa -llwip -lm_flash -lmbedtls -lnative_file -lparttab -lres_cfg -lsamgr -lsamgr_adapter -lsamgr_source -lsdio -lsec_flash -lspiffs -lsysparam -lsystem -ltoken_static -ltrans_service -ltsensor -luart -lupg -lutils_kv_store -lwifi -lwifi_flash -lwifiiot_app -lwifiservice -lwpa --end-group
> riscv32-unknown-elf-objcopy -O binary output/bin/Hi3861_wifiiot_app.out build/build_tmp/cache/Hi3861_wifiiot_app.bin
> baseimg_builder(["build/build_tmp/cache/Hi3861_wifiiot_app_base.bin", "build/build_tmp/cache/Hi3861_wifiiot_app_kernel.bin"], ["build/build_tmp/cache/Hi3861_wifiiot_app.bin"])
> cleanup(["build/build_tmp/cache/Hi3861_wifiiot_app_base.bin", "build/build_tmp/cache/Hi3861_wifiiot_app_kernel.bin"], ["build/build_tmp/cache/Hi3861_wifiiot_app.bin"])
> ota_builder(["build/build_tmp/cache/Hi3861_wifiiot_app_ota_temp.bin"], ["build/build_tmp/cache/Hi3861_wifiiot_app_base.bin", "build/build_tmp/cache/Hi3861_wifiiot_app_kernel.bin"])
> ********************package kernel&nv upgrade file********************
> upg kernel file    in: build/build_tmp/cache/Hi3861_wifiiot_app_kernel.bin
> upg normal nv file in: build/build_tmp/nv/Hi3861_wifiiot_app_normal.hnv
> upg file          out: build/build_tmp/cache/Hi3861_wifiiot_app_ota_temp.bin
> [common_head_offset=0][common_head_size=96]
> [common_key_offset=96][common_key_size=288]
> [common_head_sign_offset=384][common_head_sign_size=256]
> [section_head_offset=640][section_head_size=64]
> [upg_file_sign_offset=704][upg_file_sign_size=256]
> [padding_offset=683944][padding_size=8]
> [upg fill user info]chip:b'Hi3861'
> -------------build/build_tmp/cache/Hi3861_wifiiot_app_ota_temp.bin image info print start-------------
> [image_id=0x3c78961e][struct_version=0x0]]
> [section_offset=0x280][section_len=0xa6d30]
> [file_type=0xf0][file_version=0x0][encrypt_flag=0x42]
> [file_len=0xa6fb0][key_len=0x120]
> [file_attr=0x44]
> [hash_alg=0x0][sign_alg=0x3f][sign_param=0x0]
> [aes_key[0-1-14-15]=[0x0][0x0][0x0][0x0]]
> [aes_iv [0-1-14-15]=[0x0][0x0][0x0][0x0]]
> [common key][00]=[0x0]
> [common key][01]=[0x0]
> [common key][30]=[0x0]
> [common key][31]=[0x0]
> [common sign][00]=[0x42]
> [common sign][01]=[0x8f]
> [common sign][30]=[0x47]
> [common sign][31]=[0x4]
> [section sign][00]=[0x82]
> [section sign][01]=[0x85]
> [section sign][30]=[0x95]
> [section sign][31]=[0x9d]
> [image_id=0x3c78961e][struct_version=0x0]]
> [hash_alg=0x0][sign_alg=0x3f][sign_param=0x0]
> [section_count=0x2]
> [section0_compress=0x0][section0_offset=0x3c0][section0_len=0xa5be8]
> [section1_compress=0x0][section1_offset=0xa5fa8][section1_len=0x1000]
> -------------build/build_tmp/cache/Hi3861_wifiiot_app_ota_temp.bin image info print end--------------
> riscv32-unknown-elf-objdump -d output/bin/Hi3861_wifiiot_app.out > output/bin/Hi3861_wifiiot_app.asm
> burn_bin_builder(["output/bin/Hi3861_wifiiot_app_burn.bin", "output/bin/Hi3861_wifiiot_app_allinone.bin"], ["build/build_tmp/cache/Hi3861_wifiiot_app_ota_temp.bin", "output/bin/Hi3861_loader_signed.bin"])
> ********************package hiburn file********************
> hbin flash boot file in : output/bin/Hi3861_boot_signed.bin
> hbin factory nv file in : build/build_tmp/nv/Hi3861_wifiiot_app_factory.hnv
> hbin normal nv file  in : build/build_tmp/cache/Hi3861_wifiiot_app_ota_temp.bin
> hbin upg file        in : build/build_tmp/nv/Hi3861_wifiiot_app_factory.hnv
> hbin file           out : output/bin/Hi3861_wifiiot_app_burn.bin
> -------------output/bin/Hi3861_wifiiot_app_burn.bin image info print start-------------
> [bin_size]=[0xb3fb0]
> [image_id=0x3c78961e][struct_version=0x0]]
> [section_offset=0x280][section_len=0xa6d30]
> [file_type=0xf0][file_version=0x0][encrypt_flag=0x42]
> [file_len=0xa6fb0][key_len=0x120]
> [hash_alg=0x0][sign_alg=0x3f][sign_param=0x0]
> [aes_key[0,1,14,15]=[0x0][0x0][0x0][0x0]]
> [aes_iv[0,1,14,15]=[0x0][0x0][0x0][0x0]]
> -------------output/bin/Hi3861_wifiiot_app_burn.bin image info print end--------------
> ['output/bin/Hi3861_loader_signed.bin', 'output/bin/Hi3861_wifiiot_app_burn.bin', 'output/bin/Hi3861_boot_signed_B.bin']
> [0, 0, 2072576]
> [0, 2097152, 24576]
> [15360, 737200, 24576]
> [0, 1, 1]
> 4022250975
> boot_ota_builder(["output/bin/Hi3861_wifiiot_app_flash_boot_ota.bin"], ["output/bin/Hi3861_boot_signed.bin"])
> ********************package boot upgrade file********************
> boot upg file  in: output/bin/Hi3861_boot_signed.bin
> boot upg file out: output/bin/Hi3861_wifiiot_app_flash_boot_ota.bin
> [common_head_offset=0][common_head_size=96]
> [common_key_offset=96][common_key_size=288]
> [common_head_sign_offset=384][common_head_sign_size=256]
> [section_head_offset=640][section_head_size=64]
> [upg_file_sign_offset=704][upg_file_sign_size=256]
> [padding_offset=0][padding_size=0]
> [upg fill user info]chip:b'Hi3861'
> -------------output/bin/Hi3861_wifiiot_app_flash_boot_ota.bin image info print start-------------
> [image_id=0x3c78961e][struct_version=0x0]]
> [section_offset=0x280][section_len=0x60a0]
> [file_type=0xe1][file_version=0x0][encrypt_flag=0x42]
> [file_len=0x6320][key_len=0x120]
> [file_attr=0x44]
> [hash_alg=0x0][sign_alg=0x3f][sign_param=0x0]
> [aes_key[0-1-14-15]=[0x0][0x0][0x0][0x0]]
> [aes_iv [0-1-14-15]=[0x0][0x0][0x0][0x0]]
> [common key][00]=[0x0]
> [common key][01]=[0x0]
> [common key][30]=[0x0]
> [common key][31]=[0x0]
> [common sign][00]=[0xc9]
> [common sign][01]=[0x21]
> [common sign][30]=[0x2f]
> [common sign][31]=[0x82]
> [section sign][00]=[0x3]
> [section sign][01]=[0x99]
> [section sign][30]=[0xe6]
> [section sign][31]=[0xec]
> [image_id=0x3c78961e][struct_version=0x0]]
> [hash_alg=0x0][sign_alg=0x3f][sign_param=0x0]
> [section_count=0x1]
> [section0_compress=0x0][section0_offset=0x3c0][section0_len=0x5f60]
> [section1_compress=0x0][section1_offset=0x0][section1_len=0x0]
> -------------output/bin/Hi3861_wifiiot_app_flash_boot_ota.bin image info print end--------------
> compress_ota_builder(["output/bin/Hi3861_wifiiot_app_ota.bin"], ["build/build_tmp/cache/Hi3861_wifiiot_app_ota_temp.bin"])
> ********************package compress upgrade file********************
> compress upg file in:  build/build_tmp/cache/Hi3861_wifiiot_app_ota_temp.bin
> compress upg file out: output/bin/Hi3861_wifiiot_app_ota.bin
> lzma compress tool : /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/build/scripts/../../tools/lzma_tool/lzma_tool
> lzma    src   file : build/build_tmp/cache/Hi3861_wifiiot_app_ota_temp.bin
> lzma    out   file : build/build_tmp/cache/Hi3861_wifiiot_app_ota_temp.lzma
> 
> LZMA 19.00 (x64) : Igor Pavlov : Public domain : 2019-02-21
> 
> Input size:  683952 (0 MiB)
> Output size: 431176 (0 MiB)
> [upgbin-compressbin]0xa6fb0-0x12f000
> [common_head_offset=0][common_head_size=96]
> [common_key_offset=96][common_key_size=288]
> [common_head_sign_offset=384][common_head_sign_size=256]
> [section_head_offset=640][section_head_size=64]
> [upg_file_sign_offset=704][upg_file_sign_size=256]
> [padding_offset=432136][padding_size=8]
> [upg fill user info]chip:b'Hi3861'
> -------------output/bin/Hi3861_wifiiot_app_ota.bin image info print start-------------
> [image_id=0x3c78961e][struct_version=0x0]]
> [section_offset=0x280][section_len=0x69590]
> [file_type=0xf0][file_version=0x0][encrypt_flag=0x42]
> [file_len=0x69810][key_len=0x120]
> [file_attr=0x44]
> [hash_alg=0x0][sign_alg=0x3f][sign_param=0x0]
> [aes_key[0-1-14-15]=[0x0][0x0][0x0][0x0]]
> [aes_iv [0-1-14-15]=[0x0][0x0][0x0][0x0]]
> [common key][00]=[0x0]
> [common key][01]=[0x0]
> [common key][30]=[0x0]
> [common key][31]=[0x0]
> [common sign][00]=[0x55]
> [common sign][01]=[0x7b]
> [common sign][30]=[0xd8]
> [common sign][31]=[0x77]
> [section sign][00]=[0xf3]
> [section sign][01]=[0x29]
> [section sign][30]=[0xae]
> [section sign][31]=[0x48]
> [image_id=0x3c78961e][struct_version=0x0]]
> [hash_alg=0x0][sign_alg=0x3f][sign_param=0x0]
> [section_count=0x1]
> [section0_compress=0x1][section0_offset=0x3c0][section0_len=0x69448]
> [section1_compress=0x0][section1_offset=0x0][section1_len=0x0]
> -------------output/bin/Hi3861_wifiiot_app_ota.bin image info print end--------------
> 
> < ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ >
>                               BUILD SUCCESS
> < ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ >
> 
> See build log from: /home/openharmony/HarmonyCode/vendor/hisi/hi3861/hi3861/build/build_tmp/logs/build_kernel.log
> [197/197] STAMP obj/vendor/hisi/hi3861/hi3861/run_wifiiot_scons.stamp
> ohos wifiiot build success!