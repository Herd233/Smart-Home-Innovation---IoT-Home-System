# 获取harmony源码
[源码获取官方网址](https://gitee.com/openharmony/docs/blob/master/get-code/源码获取.md)

方式一：镜像网站下载
...

