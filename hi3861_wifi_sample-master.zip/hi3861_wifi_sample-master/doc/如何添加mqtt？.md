# 如何添加mqtt？
[连老师教程--来自华为社区精华帖，亲测可行](https://harmonyos.51cto.com/posts/1384)

注意：
由于mqtt有不少函数的形参没有调用，而这个在openharmony编译环境下是报error，
所以根据连老师做好之后，还需要解决不少报错。比如警告某个函数strlen参数没有使用，直接写个`strlen =strlen;`即可