# mqtt测试以及结果

## mqtt 连接
### 账号和密码设置
记得服务器需要生成鉴权账号

`data.username.cstring = "testuser";`
`data.password.cstring = "testpassword";`

例如我创建了一个：
账号：protea111
密码：12345678

然后相对应的账号和密码进行修改
`data.username.cstring = "protea111";`
`data.password.cstring = "12345678";`

### mqtt服务器IP设置
`char *host = "192.168.1.1"; //小邹的mqtt ip `
这个不是wifi地址，而是创建的mqtt服务器ip

### window客户端设置
见相关md或者链接：https://harmonyos.51cto.com/posts/1384
![](_v_images/20210301111134515_12783.png =900x)
订阅的主题以mqtt为主


### mqtt客户端主题名设置
`topicString.cstring = "pubtopic";`

主题是以节点为主的：
![](_v_images/20210301111909862_24885.png =797x)

### mqtt客户端订阅设置
`topicString.cstring = "substopic";`

设置好之后会在服务器端看见：
![](_v_images/20210301111737302_13786.png =579x)


## 开始测试
hisi开发板的串口先后输入：
### 连接wifi
`wifi_conn `：连接到服务器所在的wifi
可以看见如下log：
> [11:03:58.693]发→◇wifi_conn
> □
> [11:03:58.697]收←◆[wifi_connect_task_creat : 177]start to create WifiConnectTask!
> 
> wifi_conn
> 
> [11:03:58.827]收←◆RegisterWifiEvent: 0
> [WifiConnectTask : 108]EnableWifi: 0
> 
> 
> [11:03:58.894]收←◆[WifiConnectTask : 112]AddDeviceConfig: 0
> 
> 
> [11:03:59.325]收←◆[WifiConnectTask : 116]ConnectTo(0): 0
> 
> 
> [11:04:00.105]收←◆+NOTICE:SCANFINISH
> 
> [11:04:01.188]收←◆+NOTICE:CONNECTED
> OnWifiConnectionChanged 69, state = 1, info = 
> bssid: 9C:9D:7E:1C:0A:28, rssi: 0, connState: 0, reason: 0, ssid: NFS_raspberry
> [WifiConnectTask : 121]g_connected: 1
> 
> 
> [11:04:01.725]收←◆[WifiConnectTask : 128]netifapi_dhcp_start: 0
> 
> 
> [11:04:03.725]收←◆server :
> 	server_id : 192.168.1.1
> 	mask : 255.255.255.0, 1
> 	gw : 192.168.1.1
> 	T0 : 43200
> 	T1 : 21600
> 	T2 : 37800
> clients <1> :
> 	mac_idx mac             addr            state   lease   tries   rto     
> 	0       b4c9b9af6bfd    192.168.1.163   10      0       1       2       
> [WifiConnectTask : 132]netifapi_netif_common: 0


### mqtt测试
`mqtt_c_connect_test` ： 进行mqtt推送测试

看到如下log则是正常运作
> [11:04:05.053]发→◇mqtt_c_connect_test
> □
> [11:04:05.069]收←◆Sending to hostname 192.168.1.1 port 1883
> 
> [11:04:06.075]收←◆publishing reading
> 
> [11:04:07.075]收←◆publishing reading
> 
> [11:04:08.075]收←◆publishing reading
> 
> [11:04:09.075]收←◆publishing reading
> 
> [11:04:10.075]收←◆publishing reading
> 
> [11:04:11.075]收←◆publishing reading
> 
> [11:04:12.076]收←◆publishing reading

## 结果
### window客户端接收到数据
![](_v_images/20210301111020065_25147.png =1000x)


### mqtt客户端接受数据

![](_v_images/20210302144520742_9064.png)
> [14:42:53.172]收←◆message arrived hello
> publishing reading