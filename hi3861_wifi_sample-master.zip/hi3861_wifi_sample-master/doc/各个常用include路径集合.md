# 各个常用include路径集合
```
        "//utils/native/lite/include"           #harmony lite 头文件
        "//vendor/hisi/hi3861/hi3861/include"   #hisi 开发板适配的，封装的各个驱动头文件
```