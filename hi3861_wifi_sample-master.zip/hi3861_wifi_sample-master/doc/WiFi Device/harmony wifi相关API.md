# harmony wifi相关API
[官网readme](https://gitee.com/openharmony/docs/blob/master/readme/分布式通信子系统README.md)