# 让鸿蒙WiFi功能更容易使用
使用鸿蒙原始WiFI API接口进行编程，整个过程稍显繁琐，为此我们对鸿蒙原始WiFi API接口做了一层封装，形成了一套更简单易用的接口。

注：函数在 05_network/wifi_connecter.c内
调用的API在`openHarmony\vendor\hisi\hi3861\hi3861_adapter\hals\communication\wifi_lite\wifiservice\source\`下有四个文件
openHarmony
└──vendor
    └──hisi
        └──hi3861
            └──hi3861_adapter
                 └──hals
                      └──communication
                          └──wifi_lite
                             └──wifiservice
                                 └──source
                                    ├──wifi_device.c
                                    ├──wifi_hotspost.c
                                    ├──wifi_device_util.c
                                    ├──wifi_device_util.h
## 简化的API接口
### STA模式
```
int ConnectToHotspot(WifiDeviceConfig* apConfig);

void DisconnectWithHotspot(int netId);

```

#### ConnectToHotspot
```
//这玩意是调用第三方库
err_t netifapi_set_hostname(struct netif *netif, char *hostname, u8_t namelen);


int ConnectToHotspot(WifiDeviceConfig* apConfig)
{
    WifiErrorCode errCode;
    int netId = -1;

    errCode = RegisterWifiEvent(&g_defaultWifiEventListener);
    printf("RegisterWifiEvent: %d\r\n", errCode);

    errCode = EnableWifi();
    printf("EnableWifi: %d\r\n", errCode);

    errCode = AddDeviceConfig(apConfig, &netId);
    printf("AddDeviceConfig: %d\r\n", errCode);

    g_connected = 0;
    errCode = ConnectTo(netId);
    printf("ConnectTo(%d): %d\r\n", netId, errCode);

    while (!g_connected) { // wait until connect to AP
        osDelay(10);
    }
    printf("g_connected: %d\r\n", g_connected);

    g_iface = netifapi_netif_find("wlan0");
    if (g_iface) {
        err_t ret = 0;
        char* hostname = "hispark";
        ret = netifapi_set_hostname(g_iface, hostname, strlen(hostname));
        printf("netifapi_set_hostname: %d\r\n", ret);

        ret = netifapi_dhcp_start(g_iface);
        printf("netifapi_dhcp_start: %d\r\n", ret);

        osDelay(100); // wait DHCP server give me IP
#if 1
        ret = netifapi_netif_common(g_iface, dhcp_clients_info_show, NULL);
        printf("netifapi_netif_common: %d\r\n", ret);
#else
        // 下面这种方式也可以打印 IP、网关、子网掩码信息
        ip4_addr_t ip = {0};
        ip4_addr_t netmask = {0};
        ip4_addr_t gw = {0};
        ret = netifapi_netif_get_addr(g_iface, &ip, &netmask, &gw);
        if (ret == ERR_OK) {
            printf("ip = %s\r\n", ip4addr_ntoa(&ip));
            printf("netmask = %s\r\n", ip4addr_ntoa(&netmask));
            printf("gw = %s\r\n", ip4addr_ntoa(&gw));
        }
        printf("netifapi_netif_get_addr: %d\r\n", ret);
#endif
    }
    return netId;
}
```
在Hi3861_wifiiot_app.map中，可以找到
```
 .text.netifapi_dhcp_is_bound
                0x0000000000000000       0x22 build/libs/liblwip.a(netifapi.o)
 .text.netifapi_netif_call_argcb
                0x0000000000000000       0x52 build/libs/liblwip.a(netifapi.o)
 .text.netifapi_set_ip6_autoconfig_enabled
                0x0000000000000000       0x22 build/libs/liblwip.a(netifapi.o)
 .text.netifapi_netif_add_ext_callback
                0x0000000000000000       0x50 build/libs/liblwip.a(netifapi.o)
 .text.netifapi_netif_remove_ext_callback
                0x0000000000000000       0x4c build/libs/liblwip.a(netifapi.o)
                
 .text.netifapi_set_hostname
                0x0000000000000000       0x56 build/libs/liblwip.a(netifapi.o)
                
 .text.netifapi_set_vci
                0x0000000000000000       0x66 build/libs/liblwip.a(netifapi.o)
```

然后查看BUILD.gn，里面include_dir下有对lwip进行引用
```
    include_dirs = [
        "//utils/native/lite/include",
        "//kernel/liteos_m/components/cmsis/2.0",
        "//foundation/communication/interfaces/kits/wifi_lite/wifiservice",  //wifisevice
        "//vendor/hisi/hi3861/hi3861/third_party/lwip_sack/include/",        //第三方库，调用hostname等函数
    ]
```

### AP模式

```
int StartHotspot(const HotspotConfig* config);
void StopHotspot(void);
```




