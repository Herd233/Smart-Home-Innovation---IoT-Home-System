# 长时间无动作，看门狗复位log
> 收←◆**********watchdog isr**********
> **********syserr info start**********
> kernel_ver      : Hi3861V100 R001C00SPC025,2020-09-03 18:10:00
> **********Exception Information**********
> PC Task Name    : cli_uart
> 
> PC Task ID      = 10
> Cur Task ID     = 10
> Task Stack Size = 0x3600
> Exception Type  = 0x80000021
> **********reg info**********
> mepc         = 0x3f5dfa
> mstatus      = 0x1880
> mtval        = 0x0
> mcause       = 0x80000021
> ccause       = 0x0
> ra           = 0x3f82c4
> sp           = 0xfe240
> gp           = 0x11a9c0
> tp           = 0x6b43aa5a
> t0           = 0x8
> t1           = 0xffffffe0
> t2           = 0xfe4b4
> s0           = 0x0
> s1           = 0xe9c24
> a0           = 0x88
> a1           = 0xffffffff
> a2           = 0x1
> a3           = 0x0
> a4           = 0x1
> a5           = 0x9
> a6           = 0x1
> a7           = 0x10
> s2           = 0xe8ea4
> s3           = 0x88
> s4           = 0xffffffff
> s5           = 0xfe43c
> s6           = 0x1
> s7           = 0xfe432
> s8           = 0xe42cc
> s9           = 0xfe4b4
> s10          = 0x0
> s11          = 0xe4c00
> t3           = 0xe42ac
> t4           = 0x0
> t5           = 0xfe4b4
> t6           = 0x0
> **********memory info**********
> Pool Addr    = 0xe89c0
> Pool Size    = 0x2fc00
> Fail Count   = 0x0
> Peek Size    = 0x196b8
> Used Size    = 0x18dbc
> **********task info**********
> Name         : cli_uart
> 
> ID           = 10
> Status       = 0x14
> Stack Index  = 0x8
> Stack Peak   = 0x7b0
> Stack Size   = 0x3600
> SP           = 0x119880
> Stack        : 0xfb0f0 to 0xfe6f0
> Real SP      = 0xfe240
> Stack Overflow  = 0
> **********track_info**********
> current_item:0x7
> item_cnt:10
> Index   TrackType   TrackID  CurTime  Data1  Data2 
> 0001 0065 0010 0x2135 0x3f5e78 0x456dc8
> 0002 0016 0007 0x2135 0x3fa86a 0x0
> 0003 0065 0000 0x2136 0x3fa86a 0x3f5e78
> 0004 0065 0007 0x2136 0x3f5e78 0x3f5e78
> 0005 0065 0010 0x2136 0x3f5e78 0x3fa86a
> 0006 0016 0007 0x2136 0x46a0fe 0x0
> 0007 0016 0007 0x2137 0x4a3b3c 0x0
> 0008 0016 0007 0x2134 0x456dc8 0x0
> 0009 0065 0000 0x2135 0x456dc8 0x3f5e78
> 0010 0065 0007 0x2135 0x3f5e78 0x3f5e78
> **********Call Stack**********
> Call Stack 0 -- 46b3e0 addr:fe2fc
> Call Stack 1 -- 46a17c addr:fe30c
> Call Stack 2 -- 3fa390 addr:fe31c
> Call Stack 3 -- 3f6d74 addr:fe32c
> Call Stack 4 -- 4a3b12 addr:fe334
> Call Stack 5 -- 3f5d8a addr:fe33c
> Call Stack 6 -- 3fa86a addr:fe344
> Call Stack 7 -- 4a3b12 addr:fe394
> Call Stack 8 -- 46a442 addr:fe39c
> Call Stack 9 -- 4a3b12 addr:fe3a4
> Call Stack 10 -- 4a3b38 addr:fe3ac
> Call Stack 11 -- 4a3b12 addr:fe3c4
> Call Stack 12 -- 4a37fe addr:fe3cc
> Call Stack 13 -- 4a66d2 addr:fe3fc
> Call Stack 14 -- 4a6784 addr:fe5bc
> Call Stack 15 -- 4a60d2 addr:fe5dc
> Call Stack 16 -- 4a61d8 addr:fe64c
> Call Stack 17 -- 4a623c addr:fe67c
> Call Stack 18 -- 4a6278 addr:fe69c
> Call Stack 19 -- 4a6822 addr:fe6bc
> Call Stack 20 -- 3f78c0 addr:fe6dc
> Call Stack 21 -- 3f5e24 addr:fe6ec
> **********Call Stack end**********