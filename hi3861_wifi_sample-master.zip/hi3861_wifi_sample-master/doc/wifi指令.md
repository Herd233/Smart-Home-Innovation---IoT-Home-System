# wifi指令
## 1.连接wifi
`wifi_conn="ssid","keypass"`

如下
`wifi_conn="protea","12345678"`