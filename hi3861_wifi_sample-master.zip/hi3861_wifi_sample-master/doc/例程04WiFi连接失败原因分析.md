# 例程04WiFi连接失败原因分析

## 原因排查
发现是因为屏蔽了AT初始化，导致WiFi连接获取失败，
将AT模块开启，就正常了

> ready to OS start
> sdk ver:Hi3861V100R001C00SPC025 2020-09-03 18:10:00
> formatting spiffs...
> FileSystem mount ok.
> uart0 is init!
> AT init complete!
> wifi init success!
> 
> 00 00:00:00 0 132 D 0/HIVIEW: hilog init success.
> 00 00:00:00 0 132 D 0/HIVIEW: log limit init success.
> 00 00:00:00 0 132 I 1/SAMGR: Bootstrap core services(count:3).
> 00 00:00:00 0 132 I 1/SAMGR: Init service:0x4af3b8 TaskPool:0xfa6e4
> 00 00:00:00 0 132 I 1/SAMGR: Init service:0x4af3dc TaskPool:0xfad54
> 00 00:00:00 0 132 I 1/SAMGR: Init service:0x4af4ec TaskPool:0xfaf14
> 00 00:00:00 0 164 I 1/SAMGR: Init service 0x4af3dc <time: 0ms> success!
> 00 00:00:00 0 64 I 1/SAMGR: Init service 0x4af3b8 <time: 0ms> success!
> 00 00:00:00 0 8 D 0/HIVIEW: hiview init success.
> 00 00:00:00 0 8 I 1/SAMGR: Init service 0x4af4ec <time: 0ms> success!
> 00 00:00:00 0 8 I 1/SAMGR: Initialized all core system services!
> 00 00:00:00 0 64 I 1/SAMGR: Bootstrap system and application services(count:0).
> 00 00:00:00 0 64 I 1/SAMGR: Initialized all system and application services!
> 00 00:00:00 0 64 I 1/SAMGR: Bootstrap dynamic registered services(count:0).
> RegisterWifiEvent: 0
> EnableWifi: 0
> AddDeviceConfig: 0
> ConnectTo(0): 0
> +NOTICE:SCANFINISH
> +NOTICE:CONNECTED
> OnWifiConnectionChanged 58, state = 1, info = 
> bssid: 9C:9D:7E:1C:0A:28, rssi: 0, connState: 0, reason: 0, ssid: NFS_raspberry
> g_connected: 1
> iface = 993880netifapi_dhcp_start: 0
> server :
>         server_id : 0.0.0.0
>         mask : 0.0.0.0, 0
>         gw : 0.0.0.0
>         T0 : 0
>         T1 : 0
>         T2 : 0
> netifapi_netif_common: 0

原因分析
我们可以看到
> ConnectTo(0): 0
> +NOTICE:SCANFINISH
> +NOTICE:CONNECTED
> OnWifiConnectionChanged 58, state = 1, info = bssid: 9C:9D:7E:1C:0A:28, rssi: 0, connState: 0, reason: 0, ssid: NFS_raspberry
> g_connected: 1

相对应源码部分

```     g_connected = 0;
        errCode = ConnectTo(netId);
        printf("ConnectTo(%d): %d\r\n", netId, errCode);

        while (!g_connected) {
            osDelay(10);
        }
        printf("g_connected: %d\r\n", g_connected);
        osDelay(50);
```

明显`ConnectTo()`调用了相关AT指令进行WiFi连接，所以这里需要把AT指令开启