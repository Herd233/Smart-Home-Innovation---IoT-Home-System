# mqtt指令
## 1.设置mqtt服务ip和端口
`mqtt+conn="ip","port"`

示例：`mqtt+conn="192.168.1.1","1883"`

## 2.发送数据给mqtt服务器
`mqtt_send="发送的数据"`

例如
`mqtt_send="hellohisi"`

