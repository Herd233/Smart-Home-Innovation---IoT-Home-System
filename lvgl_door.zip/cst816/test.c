#include <math.h>
#include <stdlib.h>
#include <string.h>  // For memcpy
#include <stdio.h>

#include <cst816.h>
#include "cmsis_os2.h"
#include "ohos_init.h"

#include <unistd.h>
#include "hi_errno.h"
// #include "iot_i2c.h"
#include "hi_time.h"
#include "iot_gpio.h"
#include "iot_gpio_ex.h"
#include "hi_gpio.h"

#include "iot_errno.h"
#include "iot_i2c.h"
#include "hi_i2c.h"



CST816_Info	CST816_Instance;			//创建CST816实例



//IIC起始信号
void CST816_IIC_Start(void)
{
    IoSetPull(TP_SDA_Pin,IOT_IO_PULL_UP);
    CST816_SDA_OUT();
        
    CST816_SDA_Set();
    CST816_SCL_Set();
    hi_udelay(delay_num);	
    CST816_SDA_Clr();
    hi_udelay(delay_num); 
    CST816_SCL_Clr();
}

//IIC停止信号
void CST816_IIC_Stop(void)
{
    IoSetPull(TP_SDA_Pin,IOT_IO_PULL_UP);
	CST816_SDA_OUT();
	
	CST816_SCL_Clr(); 
	CST816_SDA_Clr();  
	hi_udelay(delay_num);	
	CST816_SCL_Set();
	CST816_SDA_Set();
	hi_udelay(delay_num);
}


//发送ACK应答
void CST816_IIC_ACK(void)
{
    IoSetPull(TP_SDA_Pin,IOT_IO_PULL_UP);
    CST816_SDA_OUT();
        
    CST816_SCL_Clr();
    CST816_SDA_Clr();
    hi_udelay(delay_num);     
    CST816_SCL_Set();
    hi_udelay(delay_num);                  
    CST816_SCL_Clr();   
}


//发送NACK不应答
void CST816_IIC_NACK(void)
{
    IoSetPull(TP_SDA_Pin,IOT_IO_PULL_UP);
    CST816_SDA_OUT();
        
    CST816_SCL_Clr();
    CST816_SDA_Set();
    hi_udelay(delay_num);     
    CST816_SCL_Set();
    hi_udelay(delay_num);                  
    CST816_SCL_Clr(); 
}


//等待IIC应答信号
unsigned char CST816_IIC_Wait_ACK(void)
{
    unsigned char t = 0;

    IoSetPull(TP_SDA_Pin,IOT_IO_PULL_UP);
	CST816_SDA_IN();
	CST816_SDA_Set();
	hi_udelay(delay_num); 
	CST816_SCL_Set();
	hi_udelay(delay_num); 

    IotGpioValue CST816_SDA_Get = IOT_GPIO_VALUE0;
    IoTGpioGetInputVal(TP_SDA_Pin,&CST816_SDA_Get);
	while(CST816_SDA_Get == IOT_GPIO_VALUE1)
	{
		t++;
		if(t>250)
		{
			CST816_IIC_Stop();
			return 1;
		}
	}
  CST816_SCL_Clr();              
  return 0;	
}

//IIC发送一字节数据
void CST816_IIC_SendByte(unsigned char byte)
{
	unsigned char  BitCnt;
    IoSetPull(TP_SDA_Pin,IOT_IO_PULL_UP);
	CST816_SDA_OUT();
	CST816_SCL_Clr();
	for(BitCnt=0;BitCnt<8;BitCnt++)//要传送的数据长度为8位
	{
		if(byte&0x80) CST816_SDA_Set();//判断发送位
		else CST816_SDA_Clr(); 
		byte<<=1;
		hi_udelay(delay_num); 
		CST816_SCL_Set();
		hi_udelay(delay_num);
		CST816_SCL_Clr();
		hi_udelay(delay_num);
	}
}

//IIC接收一字节数据
unsigned char CST816_IIC_RecvByte(void)
{
    unsigned char retc;
    unsigned char BitCnt;
    retc=0; 
    IoSetPull(TP_SDA_Pin,IOT_IO_PULL_UP);
    CST816_SDA_IN();//置数据线为输入方式                
    for(BitCnt=0;BitCnt<8;BitCnt++)
    {        
            CST816_SCL_Clr();
            hi_udelay(delay_num);
            CST816_SCL_Set();//置时钟线为高使数据线上数据有效                
            retc=retc<<1;
			    IotGpioValue CST816_SDA_Get = IOT_GPIO_VALUE0;
    		IoTGpioGetInputVal(TP_SDA_Pin,&CST816_SDA_Get);	
            if(CST816_SDA_Get == IOT_GPIO_VALUE1) retc++;//读数据位,接收的数据位放入retc中 
            hi_udelay(delay_num);
    }
    return(retc);
}


//IIC写入指定寄存器数据
void CST816_IIC_WriteREG(unsigned char reg,unsigned char date)
{
	CST816_IIC_Start();
	CST816_IIC_SendByte(0x2A);
	CST816_IIC_Wait_ACK();
	CST816_IIC_SendByte(reg);
	CST816_IIC_Wait_ACK();
	CST816_IIC_SendByte(date);
	CST816_IIC_Wait_ACK();
	CST816_IIC_Stop();
	hi_udelay(10000); // 10ms
}


//IIC读取指定寄存器数据
unsigned char CST816_IIC_ReadREG(unsigned char reg)
{
	unsigned char data;
	CST816_IIC_Start();
	CST816_IIC_SendByte(0x2A);
	CST816_IIC_Wait_ACK();
	CST816_IIC_SendByte(reg);
	CST816_IIC_Wait_ACK();
	CST816_IIC_Start();
//	delay_us(4);
	CST816_IIC_SendByte(0x2B);
	CST816_IIC_Wait_ACK();
	data=CST816_IIC_RecvByte();
	CST816_IIC_ACK();
	CST816_IIC_Stop();
//	delay_us(5);
	return data;
}


void CST816_Init(void)
{
    IoTGpioInit(TP_SCL_Pin); 
    // IoSetFunc(TP_SCL_Pin,HI_IO_FUNC_GPIO_1_I2C1_SCL);
	IoSetFunc(TP_SCL_Pin,6);
    IoTGpioInit(TP_SDA_Pin); 
    // IoSetFunc(TP_SDA_Pin,HI_IO_FUNC_GPIO_0_I2C1_SDA);
	IoSetFunc(TP_SDA_Pin,6);
}


unsigned char CST816_Get_ChipID()
{
	return CST816_IIC_ReadREG(ChipID);    //读取芯片ID
}

void CST816_Get_XY()
{
 
    //这个函数非常值得注意，为什么没有使用上面提到的直接读取指定寄存器的函数，
    //因为这个CST816芯片的原因，当读取过XY坐标四个寄存器之中的任意一个之后，其他寄存器会被清空，得到的数据不准确。
    //因此必须连续读取，这样也可以学习下IIC总线的读取逻辑嘛对不对。
 
	unsigned char temp[4];
	unsigned int x,y;
	
	i2c_start(HI_I2C_IDX_1);
	i2c_send_byte(HI_I2C_IDX_1,0x2A);
	i2c_wait(HI_I2C_IDX_1);
	i2c_send_byte(HI_I2C_IDX_1,0x03);
	i2c_wait(HI_I2C_IDX_1);
	i2c_start(HI_I2C_IDX_1);
//	delay_us(4);
	i2c_send_byte(HI_I2C_IDX_1,0x2B);
	i2c_wait(HI_I2C_IDX_1);
    i2c_receive_byte(HI_I2C_IDX_1,&temp[0]);
	i2c_wait(HI_I2C_IDX_1);
    i2c_receive_byte(HI_I2C_IDX_1,&temp[1]);
	i2c_wait(HI_I2C_IDX_1);
    i2c_receive_byte(HI_I2C_IDX_1,&temp[2]);
	i2c_wait(HI_I2C_IDX_1);
    i2c_receive_byte(HI_I2C_IDX_1,&temp[3]);
	i2c_wait(HI_I2C_IDX_1);
	i2c_stop(HI_I2C_IDX_1);
	
	x=(unsigned int)((temp[0]&0x0F)<<8)|temp[1];//(temp[0]&0X0F)<<4|
	y=(unsigned int)((temp[2]&0x0F)<<8)|temp[3];//(temp[2]&0X0F)<<4|
	if(x<240&&y<280)
	{
		CST816_Instance.X_Pos	=	x;
		CST816_Instance.Y_Pos	=	y;
	}
}

unsigned char CST816_Get_Sta()
{
	unsigned char sta;
	
    i2c_start(HI_I2C_IDX_1);
    i2c_send_byte(HI_I2C_IDX_1,0x2A);
    i2c_wait(HI_I2C_IDX_1);
    i2c_send_byte(HI_I2C_IDX_1,0x01);
    i2c_wait(HI_I2C_IDX_1);
    i2c_start(HI_I2C_IDX_1);
//	delay_us(4);
    i2c_send_byte(HI_I2C_IDX_1,0x2B);
    i2c_wait(HI_I2C_IDX_1);
    i2c_receive_byte(HI_I2C_IDX_1,&sta);
    i2c_wait(HI_I2C_IDX_1);
    i2c_receive_byte(HI_I2C_IDX_1,&sta);
    i2c_wait(HI_I2C_IDX_1);
    i2c_stop(HI_I2C_IDX_1);
	if(sta!=255&sta!=0)
    {
        CST816_Instance.Sta = 1;
        return 1;
    }
	else
    {
        CST816_Instance.Sta = 0;
        return 0; 
    }     
}









