#ifndef CST816_H
#define CST816_H

#include "hi_io.h"

#define delay_num 4        //宏定义延时时间

// #define TP_SCL_Pin  IOT_IO_NAME_GPIO_1 //gpio1复用I2C1_SCL    
// #define TP_SDA_Pin  IOT_IO_NAME_GPIO_0 //gpio0复用I2C1_SDA

#define TP_SCL_Pin  HI_IO_NAME_GPIO_1 //gpio1复用I2C1_SCL    
#define TP_SDA_Pin  HI_IO_NAME_GPIO_0 //gpio0复用I2C1_SDA

#define CST816_I2C_IDX	HI_I2C_IDX_1

#define CST816_DEVICE_ADDR   0x15
#define CST816_READ_ADDR	0x2B
#define CST816_WRITE_ADDR    0x2A


#define CST816_SCL_Clr() 	IoTGpioSetOutputVal(TP_SCL_Pin, IOT_GPIO_VALUE0)
#define CST816_SCL_Set() 	IoTGpioSetOutputVal(TP_SCL_Pin, IOT_GPIO_VALUE1)

// #define CST816_SDA_IN()     hi_gpio_set_dir(TP_SDA_Pin,HI_GPIO_DIR_IN)
#define CST816_SDA_IN()     IoTGpioSetDir(TP_SDA_Pin,HI_GPIO_DIR_IN)
//#define CST816_SDA_Get()	IoTGpioGetInputVal(TP_SDA_Pin,data)

// #define CST816_SDA_OUT()    hi_gpio_set_dir(TP_SDA_Pin,HI_GPIO_DIR_OUT)
#define CST816_SDA_OUT()    IoTGpioSetDir(TP_SDA_Pin,HI_GPIO_DIR_OUT)
#define CST816_SDA_Clr() 	IoTGpioSetOutputVal(TP_SDA_Pin, IOT_GPIO_VALUE0)
#define CST816_SDA_Set() 	IoTGpioSetOutputVal(TP_SDA_Pin, IOT_GPIO_VALUE1)

//CST816寄存器
#define GestureID			0x01		//手势寄存器
#define FingerNum			0x02		//手指数量
#define XposH				0x03		//x高四位
#define XposL				0x04		//x低八位
#define YposH				0x05		//y高四位
#define YposL				0x06		//y低八位
#define ChipID				0xA7		//芯片型号
#define	MotionMask		    0xEC		//触发动作
#define AutoSleepTime	    0xF9		//自动休眠
#define IrqCrl				0xFA		//中断控制
#define AutoReset			0xFB		//无手势休眠
#define LongPressTime	    0xFC		//长按休眠
#define DisAutoSleep	    0xFE		//使能低功耗模式

typedef struct
{
	unsigned char chipID;
	unsigned int X_Pos;			//X坐标
	unsigned int Y_Pos;			//Y坐标
	unsigned char Sta;			//记录触摸状态	
}CST816_Info;

extern CST816_Info CST816_Instance;

void CST816_IIC_Start(void);
void CST816_IIC_Stop(void);
void CST816_IIC_ACK(void);
void CST816_IIC_NACK(void);
unsigned char CST816_IIC_Wait_ACK(void);
void CST816_IIC_SendByte(unsigned char byte);
unsigned char CST816_IIC_RecvByte(void);
void CST816_IIC_WriteREG(unsigned char reg,unsigned char date);
unsigned char CST816_IIC_ReadREG(unsigned char reg);
void CST816_Init(void);
unsigned char CST816_Get_ChipID();
void CST816_Get_XY();
unsigned char CST816_Get_Sta();

#endif