#include <math.h>
#include <stdlib.h>
#include <string.h>  // For memcpy
#include <stdio.h>
#include "stdint.h"

#include "gt911.h"
#include "cmsis_os2.h"
#include "ohos_init.h"

#include <unistd.h>
#include "hi_errno.h"
// #include "iot_i2c.h"
#include "hi_time.h"
#include "iot_gpio.h"
#include "iot_gpio_ex.h"
#include "hi_gpio.h"

#include "iot_errno.h"
#include "iot_i2c.h"
#include "hi_i2c.h"
#include "hi_io.h"

#include "base_ssd1306_example.h"

//默认为touchtype=0的数据.
uint8_t CMD_RDX=0XD0;
uint8_t CMD_RDY=0X90;

//触摸相关参数
_m_tp_dev tp_dev;
// _m_tp_dev tp_dev=
// {
// 	TP_Init,
// 	TP_Scan,
// 	TP_Adjust,
// 	0,
// 	0, 
// 	0,
// 	0,
// 	0,
// 	0,	  	 		
// 	0,
// 	0,	  	 		
// };	

//GT911（原GT9147）配置参数表
//第一个字节为版本号(0X60),必须保证新的版本号大于等于GT911内部
//flash原有版本号,才会更新配置.
const uint8_t GT9147_CFG_TBL[]=
{ 
	0X60,0XE0,0X01,0X20,0X03,0X05,0X35,0X00,0X02,0X08,
	0X1E,0X08,0X50,0X3C,0X0F,0X05,0X00,0X00,0XFF,0X67,
	0X50,0X00,0X00,0X18,0X1A,0X1E,0X14,0X89,0X28,0X0A,
	0X30,0X2E,0XBB,0X0A,0X03,0X00,0X00,0X02,0X33,0X1D,
	0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X32,0X00,0X00,
	0X2A,0X1C,0X5A,0X94,0XC5,0X02,0X07,0X00,0X00,0X00,
	0XB5,0X1F,0X00,0X90,0X28,0X00,0X77,0X32,0X00,0X62,
	0X3F,0X00,0X52,0X50,0X00,0X52,0X00,0X00,0X00,0X00,
	0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
	0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X0F,
	0X0F,0X03,0X06,0X10,0X42,0XF8,0X0F,0X14,0X00,0X00,
	0X00,0X00,0X1A,0X18,0X16,0X14,0X12,0X10,0X0E,0X0C,
	0X0A,0X08,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
	0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
	0X00,0X00,0X29,0X28,0X24,0X22,0X20,0X1F,0X1E,0X1D,
	0X0E,0X0C,0X0A,0X08,0X06,0X05,0X04,0X02,0X00,0XFF,
	0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
	0X00,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,
	0XFF,0XFF,0XFF,0XFF
};


//触摸复位操作以便于设定IIC地址
void GT911_RST(void)
{
    //把I2C地址设为0xBA/0xBB
    IoTGpioSetDir(TP_RST_Pin,HI_GPIO_DIR_OUT); // RST
    IoTGpioSetDir(TP_INT_Pin,HI_GPIO_DIR_OUT); // INT
    IoTGpioSetOutputVal(TP_RST_Pin, IOT_GPIO_VALUE0);
    IoTGpioSetOutputVal(TP_INT_Pin, IOT_GPIO_VALUE0);
    usleep(10000); // 10ms
    IoTGpioSetOutputVal(TP_RST_Pin, IOT_GPIO_VALUE1); 
    usleep(10000); // 10ms

    IoTGpioSetDir(TP_INT_Pin,HI_GPIO_DIR_IN);
    
}

/*
* I2C引脚初始化并配置从机写地址和读地址
* @return
*        - 0:初始化成功(成功读到chipID=911)
*        - 1:初始化失败
*/
uint8_t GT911_Init(void)
{

    // IoTGpioInit(TP_SCL_Pin);
    // IoTGpioInit(TP_SDA_Pin);

    hi_io_set_pull(TP_SDA_Pin, HI_IO_PULL_UP);
    hi_io_set_pull(TP_SCL_Pin, HI_IO_PULL_UP);

    //将引脚功能设置为 I2C 引脚
    hi_io_set_func(TP_SDA_Pin, HI_IO_FUNC_GPIO_0_I2C1_SDA);
    hi_io_set_func(TP_SCL_Pin, HI_IO_FUNC_GPIO_1_I2C1_SCL);

    //初始化 I2C1
    uint32_t ret = IoTI2cInit(GT911_I2C_IDX, 400 * 1000);
    if (ret != IOT_SUCCESS) {
        printf("Init i2c Fail. ret = %d\n", ret);
    }
    printf("Init i2c succ.\n");

    GT911_RST();
    printf("GT911 slaveAddr set succ.\n");

    uint8_t temp[5];
    GT911_RD_Reg(GT_CMD_RD,GT_PID_REG,temp,4);//读取产品ID    
	if(strcmp((char*)temp,"911")==0)//ID==911
	{
		temp[0]=0X02;			
		GT911_WR_Reg(GT_CMD_WR,GT_CTRL_REG,temp,1);//软复位GT911
		GT911_RD_Reg(GT_CMD_RD,GT_CFGS_REG,temp,1);//读取GT_CFGS_REG寄存器
		if(temp[0]<0X60)//默认版本比较低,需要更新flash配置
		{
			printf("Default Ver:%d\r\n",temp[0]);
		}
		usleep(10000);
		temp[0]=0X00;	 
		GT911_WR_Reg(GT_CMD_WR,GT_CTRL_REG,temp,1);//结束复位   
		return 0;
	} 
	return 1;
}

uint8_t GT911_SoftSet(void)
{
    uint8_t temp[5];
    GT911_RD_Reg(GT_CMD_RD,GT_PID_REG,temp,4);//读取产品ID    
	if(strcmp((char*)temp,"911")==0)//ID==911
	{
		temp[0]=0X02;			
		GT911_WR_Reg(GT_CMD_WR,GT_CTRL_REG,temp,1);//软复位GT911
		GT911_RD_Reg(GT_CMD_RD,GT_CFGS_REG,temp,1);//读取GT_CFGS_REG寄存器
		if(temp[0]<0X60)//默认版本比较低,需要更新flash配置
		{
			printf("Default Ver:%d\r\n",temp[0]);
		}
		usleep(10000);
		temp[0]=0X00;	 
		GT911_WR_Reg(GT_CMD_WR,GT_CTRL_REG,temp,1);//结束复位   
		return 0;
	} 
	return 1;
}

const uint16_t GT911_TPX_TBL[5]={GT_TP1_REG,GT_TP2_REG,GT_TP3_REG,GT_TP4_REG,GT_TP5_REG};
/*
*   扫描触摸屏(采用查询方式)
*   @parm
*       - mode:0，正常扫描
*   @return:当前触屏状态
*       - 0:触摸屏无触摸
*       - 1:触摸屏有触摸
*/
uint8_t GT911_Scan(uint8_t mode)
{
	uint8_t buf[4];
	uint8_t i=0;
	uint8_t res=0;
	uint8_t temp;
	static uint8_t t=0;//控制查询间隔,从而降低CPU占用率   
	t++;
	if((t%10)==0||t<10)//空闲时,每进入10次CTP_Scan函数才检测1次,从而节省CPU使用率
	{
		GT911_RD_Reg(GT_CMD_RD,GT_GSTID_REG,&mode,1);//读取触摸点的状态 
		//printf("mode:0x%x\r\n",mode);
		if((mode&0XF)&&((mode&0XF)<6))
		{
			temp=0XFF<<(mode&0XF);//将点的个数转换为1的位数,匹配tp_dev.sta定义 
			tp_dev.sta=(~temp)|TP_PRES_DOWN|TP_CATH_PRES; 
			for(i=0;i<5;i++)
			{
				if(tp_dev.sta&(1<<i))	//触摸有效?
				{
					GT911_RD_Reg(GT_CMD_RD,GT911_TPX_TBL[i],buf,4);	//读取XY坐标值

                    tp_dev.y[i]=((uint16_t)buf[1]<<8)+buf[0];
                    tp_dev.x[i]=480-(((uint16_t)buf[3]<<8)+buf[2]);
 
					printf("x[%d]:%d,y[%d]:%d\r\n",i,tp_dev.x[i],i,tp_dev.y[i]);//串口打印坐标，用于调试
				}			
			} 
			res=1;
			if(tp_dev.x[0]==0 && tp_dev.y[0]==0)mode=0;	//读到的数据都是0,则忽略此次数据
			t=0;		//触发一次,则会最少连续监测10次,从而提高命中率
		}
 		if(mode&0X80&&((mode&0XF)<6))
		{
			temp=0;
			GT911_WR_Reg(GT_CMD_WR,GT_GSTID_REG,&temp,1);//清标志 		
		}
	}
	if((mode&0X8F)==0X80)//无触摸点按下
	{ 
		if(tp_dev.sta&TP_PRES_DOWN)	//之前是被按下的
		{
			tp_dev.sta&=~(1<<7);	//标记按键松开
		}else						//之前就没有被按下
		{ 
			tp_dev.x[0]=0xffff;
			tp_dev.y[0]=0xffff;
			tp_dev.sta&=0XE0;	//清除点有效标记	
		}	 
	} 	
	if(t>240)t=10;//重新从10开始计数
	return res;    
}

/*
* 向GT911寄存器写入一次数据
* @parm
*       - slave_addr:GT911写地址
*       - register_addr:起始寄存器地址
*       - buffer:数据缓存区
*       - buffLen:写数据长度
* @return
*       - HI_ERR_SUCCESS:写入成功 
*       - HI_ERR_FAILURE:写入失败
*/
hi_u32 GT911_WR_Reg(uint8_t slave_addr,hi_u16 register_addr, uint8_t* buffer,uint8_t buffLen)
{
    hi_i2c_data data = { 0 };
    
    // 先写入寄存器地址
    if(0 != register_addr)
    {
        uint8_t data_buf[] = {((register_addr >> 8) & 0xFF),
                                (register_addr  & 0xFF)};

        data.send_buf = data_buf;
        data.send_len = sizeof(data_buf);
        uint32_t retval = hi_i2c_write(GT911_I2C_IDX, slave_addr, &data);
        if (retval != HI_ERR_SUCCESS) {
            printf("REG I2cWrite(%02X) failed, %0X!\n", buffer[0], retval);
            return retval;
        }
    }

    // 向从机的寄存器写入数据
    data.send_buf = buffer;
    data.send_len = buffLen;
    uint32_t retval = hi_i2c_write(GT911_I2C_IDX, slave_addr, &data);
    if (retval != HI_ERR_SUCCESS) {
        printf("REG_DATA I2cWrite(%02X) failed, %0X!\n", buffer[0], retval);
        return retval;
    }

    return HI_ERR_SUCCESS;
}

/*
* 向GT911寄存器读出一次数据
* @parm
*       - slave_addr:GT911读地址
*       - register_addr:起始寄存器地址
*       - buffer:数据缓存区
*       - buf_len:写数据长度
* @return
*       - HI_ERR_SUCCESS:读取成功
*       - HI_ERR_FAILURE:读取失败
*/
hi_u32 GT911_RD_Reg(uint8_t slave_addr,hi_u16 register_addr, uint8_t* buffer, uint32_t buffLen)
{
    hi_i2c_data data = { 0 }; 

    // 向从设备写入寄存器地址
    if(0 != register_addr)
    {
        uint8_t data_buf[] = {((register_addr >> 8) & 0xFF),
                                (register_addr  & 0xFF)};
    
        data.send_buf = data_buf;
        data.send_len = sizeof(data_buf);
        uint32_t retval = hi_i2c_write(GT911_I2C_IDX, GT_CMD_WR, &data);
        if (retval != HI_ERR_SUCCESS) {
            printf("REG I2cWrite(%02X) failed, %0X!\n", buffer[0], retval);
            return retval;
        }
    }

    // 向从设备的寄存器读取数据
    data.receive_buf = buffer;
    data.receive_len = buffLen;
    uint32_t retval = hi_i2c_read(GT911_I2C_IDX, slave_addr, &data);
    if (retval != HI_ERR_SUCCESS) {
        printf("I2cRead() failed, %0X!\n", retval);
        return retval;
    }

    return HI_ERR_SUCCESS; 
 
}

/*
* 触摸屏初始化
* @parm
* @return
*       - 1:没有进行校准
*       - 0:进行过校准
*/
// uint8_t TP_Init(void)
// {
//     tp_dev.scan=GT911_Scan;       	//扫描函数指向GT911触摸屏扫描
//     tp_dev.touchtype |= 0X80;       /* 标记电容屏 */
//     return 1;
// }

/*
*触摸按键扫描
* @parm
*       - tp:0,屏幕坐标;1,物理坐标(校准等特殊场合用)
* @return 当前触屏状态
*       - 0:触屏无触摸
        - 1:触屏有触摸
*/
// uint8_t TP_Scan(uint8_t tp)
// {
//     uint8_t PEN;
//     IoTGpioGetInputVal(TP_INT_Pin,&PEN);		   
// 	if(PEN==0)//有按键按下
// 	{
// 		if(tp)TP_Read_XY2(&tp_dev.x[0],&tp_dev.y[0]);//读取物理坐标
// 		else if(TP_Read_XY2(&tp_dev.x[0],&tp_dev.y[0]))//读取屏幕坐标
// 		{
// 	 		tp_dev.x[0]=tp_dev.xfac*tp_dev.x[0]+tp_dev.xoff;//将结果转换为屏幕坐标
// 			tp_dev.y[0]=tp_dev.yfac*tp_dev.y[0]+tp_dev.yoff;  
// 	 	} 
// 		if((tp_dev.sta&TP_PRES_DOWN)==0)//之前没有被按下
// 		{		 
// 			tp_dev.sta=TP_PRES_DOWN|TP_CATH_PRES;//按键按下  
// 			tp_dev.x[4]=tp_dev.x[0];//记录第一次按下时的坐标
// 			tp_dev.y[4]=tp_dev.y[0];  	   			 
// 		}
		
// 		printf("x:%d\r\n",tp_dev.x[0]);	
// 		printf("y:%d\r\n",tp_dev.y[0]);	  //调试TP坐标时使用
				   
// 	}else
// 	{
// 		if(tp_dev.sta&TP_PRES_DOWN)//之前是被按下的
// 		{
// 			tp_dev.sta&=~(1<<7);//标记按键松开	
// 		}else//之前就没有被按下
// 		{
// 			tp_dev.x[4]=0;
// 			tp_dev.y[4]=0;
// 			tp_dev.x[0]=0xffff;
// 			tp_dev.y[0]=0xffff;
// 		}	    
// 	}
// 	return tp_dev.sta&TP_PRES_DOWN;//返回当前的触屏状态
// }




