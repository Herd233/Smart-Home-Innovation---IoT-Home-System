
Simple Spinbox
"""""""""""""""""""""""

.. lv_example:: widgets/spinbox/lv_example_spinbox_1
  :language: c

