#include <stdio.h>
#include <unistd.h>

#include "ohos_init.h"
#include "cmsis_os2.h"
#include "ttp229.h"

static void Key_Task(void *arg)
{
    uint16_t num = 0;
    TouchKey_init();

    while (1)
    {
        num = Get_KeyNum();
        printf("num=%d\r\n", num);
    }
    return 0;
}

static void Key_Entry(void)
{
    osThreadAttr_t attr;

    attr.name = "Key_Task";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 1024 * 20;
    attr.priority = osPriorityNormal;

    if (osThreadNew(Key_Task, NULL, &attr) == NULL)
    {
        printf("[Key_Task] Falied to create Key_Task!\n");
    }
    printf("test!/n");
}

SYS_RUN(Key_Entry);