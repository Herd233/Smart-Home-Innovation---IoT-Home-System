#include "ttp229.h"

#include "cmsis_os2.h"
#include <unistd.h>

#include "hi_errno.h"
#include "hi_time.h"
#include "hi_gpio.h"
#include "hi_io.h"

#include "iot_gpio.h"
#include "iot_gpio_ex.h"

void TouchKey_init(void)
{
    TTP229_SDA_OUT();
    TTP229_SDA_Clr();
    TTP229_SCL_Clr();
    TouchKey_Read();
}

uint16_t TouchKey_Read(void)
{
    uint8_t i;
    uint16_t re_val = 0;
    TTP229_SDA_OUT();
    TTP229_SDA_Set();
    usleep(100);
    TTP229_SDA_Clr();
    usleep(20);

    TTP229_SDA_IN();
    for (i = 0; i < 16; i++)
    {
        TTP229_SCL_Set();
        usleep(200);
        TTP229_SCL_Clr();
        uint8_t SDA_value;
        IoTGpioGetInputVal(TP_SDA_Pin, &SDA_value);
        if (SDA_value == 1)
        {
            re_val |= (1 << i);
        }
        usleep(200);
    }
    TaskMsleepp(2); // 根据时序图延时2ms， 不然容易出现按键串扰现象
    return re_val;
}

uint16_t PreKeyNum;
uint16_t NowKeyNum;

uint8_t Get_KeyNum(void)
{
    uint8_t key_num;
    NowKeyNum = TouchKey_Read();
    if ((NowKeyNum & 0x0001) && !(PreKeyNum & 0x0001))
    {
        key_num = 1;
    }
    if ((NowKeyNum & 0x0002) && !(PreKeyNum & 0x0002))
    {
        key_num = 2;
    }
    if ((NowKeyNum & 0x0004) && !(PreKeyNum & 0x0004))
    {
        key_num = 3;
    }
    if ((NowKeyNum & 0x0008) && !(PreKeyNum & 0x0008))
    {
        key_num = 4;
    }
    if ((NowKeyNum & 0x0010) && !(PreKeyNum & 0x0010))
    {
        key_num = 5;
    }
    if ((NowKeyNum & 0x0020) && !(PreKeyNum & 0x0020))
    {
        key_num = 6;
    }
    if ((NowKeyNum & 0x0040) && !(PreKeyNum & 0x0040))
    {
        key_num = 7;
    }
    if ((NowKeyNum & 0x0080) && !(PreKeyNum & 0x0080))
    {
        key_num = 8;
    }
    if ((NowKeyNum & 0x0100) && !(PreKeyNum & 0x0100))
    {
        key_num = 9;
    }
    if ((NowKeyNum & 0x0200) && !(PreKeyNum & 0x0200))
    {
        key_num = 10;
    }
    if ((NowKeyNum & 0x0400) && !(PreKeyNum & 0x0400))
    {
        key_num = 11;
    }
    if ((NowKeyNum & 0x0800) && !(PreKeyNum & 0x0800))
    {
        key_num = 12;
    }
    if ((NowKeyNum & 0x1000) && !(PreKeyNum & 0x1000))
    {
        key_num = 13;
    }
    if ((NowKeyNum & 0x2000) && !(PreKeyNum & 0x2000))
    {
        key_num = 14;
    }
    if ((NowKeyNum & 0x4000) && !(PreKeyNum & 0x4000))
    {
        key_num = 15;
    }
    if ((NowKeyNum & 0x8000) && !(PreKeyNum & 0x8000))
    {
        key_num = 16;
    }

    PreKeyNum = NowKeyNum;
    return key_num;
}
