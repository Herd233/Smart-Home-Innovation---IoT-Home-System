#ifndef TTP_229_H
#define TTP_229_H

#include "hi_io.h"
#include "stdint.h"
#define TP_SCL_Pin HI_IO_NAME_GPIO_1 // gpio1复用I2C1_SCL
#define TP_SDA_Pin HI_IO_NAME_GPIO_0 // gpio0复用I2C1_SDA

#define TTP229_SCL_Clr() IoTGpioSetOutputVal(TP_SCL_Pin, IOT_GPIO_VALUE0)
#define TTP229_SCL_Set() IoTGpioSetOutputVal(TP_SCL_Pin, IOT_GPIO_VALUE1)

#define TTP229_SDA_IN() IoTGpioSetDir(TP_SDA_Pin, HI_GPIO_DIR_IN)
#define TTP229_SDA_OUT() IoTGpioSetDir(TP_SDA_Pin, HI_GPIO_DIR_OUT)
#define TTP229_SDA_Clr() IoTGpioSetOutputVal(TP_SDA_Pin, IOT_GPIO_VALUE0)
#define TTP229_SDA_Set() IoTGpioSetOutputVal(TP_SDA_Pin, IOT_GPIO_VALUE1)

void TouchKey_init(void);
uint16_t TouchKey_Read(void);
uint8_t Get_KeyNum(void);
#endif // !__HAL_BSP_SHT20_H__